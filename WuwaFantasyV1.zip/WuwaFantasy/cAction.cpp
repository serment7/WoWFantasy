#include "stdAfx.h"
#include "cAction.h"


cAction::cAction(void)
	: m_fPassedTime(0.0f)
	, m_pOwner(NULL)
	, m_fActionTime(0.0f)
	, m_pDelegate(NULL)
{
}


cAction::~cAction(void)
{
}

void cAction::SetOwner( cGameObject* pOwner )
{
	m_pOwner = pOwner;
}
