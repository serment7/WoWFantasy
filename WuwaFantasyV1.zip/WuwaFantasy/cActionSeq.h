#pragma once
#include "cAction.h"

class cActionSeq
	: public cAction
	, public iActionDelegate
{
protected:
	std::vector<cAction*>	m_vecAction;
	int						m_nSeqNo;

public:
	cActionSeq(void);
	virtual ~cActionSeq(void);

	virtual void AddAction(cAction* pAction)
	{
		pAction->AddRef();
		m_vecAction.push_back(pAction);
	}
	virtual void Start() override;
	virtual void Update() override;

	virtual void OnActionFinish(cAction* pSender) override;
};

