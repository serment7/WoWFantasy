#include "StdAfx.h"
#include "cFrame.h"
#include "cMtlTex.h"

cFrame::cFrame(void)
	: m_pMtlTex(NULL)
{
	D3DXMatrixIdentity(&m_matWorld);
	D3DXMatrixIdentity(&m_matLocal);
}

cFrame::~cFrame(void)
{
	SAFE_RELEASE(m_pMtlTex);
}

void cFrame::Update( int nKeyFrame, cFrame* pParent )
{
	D3DXMATRIXA16 matT, matR;
	LocalTranslation(nKeyFrame, matT);
	LocalRotation(nKeyFrame, matR);

	m_matWorld = matR * matT;

	if (pParent)
	{
		m_matWorld *= pParent->GetWorldTM();
	}

	for each(auto p in m_vecChild)
	{
		p->Update(nKeyFrame, this);
	}
}

void cFrame::Render()
{
	if (m_pMtlTex)
	{
		g_pD3DDevice->SetMaterial(&m_pMtlTex->GetMtl());
		g_pD3DDevice->SetTexture(0, m_pMtlTex->GetTexture());
	}

	g_pD3DDevice->SetTransform(D3DTS_WORLD, &m_matWorld);
	g_pD3DDevice->SetFVF(ST_PNT_VERTEX::FVF);
	g_pD3DDevice->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,
		m_vecVertex.size() / 3,
		&m_vecVertex[0],
		sizeof(ST_PNT_VERTEX));

	for each(auto p in m_vecChild)
	{
		p->Render();
	}
}

void cFrame::AddChild( cFrame* pFrame )
{
	m_vecChild.push_back(pFrame);
}

void cFrame::Destroy()
{
	for each(auto p in m_vecChild)
	{
		p->Destroy();
	}
	Release();
}

void cFrame::CalcOriginLocalTM( cFrame* pParent )
{
	m_matLocal = m_matWorld;
	if (pParent)
	{
		D3DXMATRIXA16& matParent = pParent->GetWorldTM();
		D3DXMATRIXA16 matInvParent;
		D3DXMatrixInverse(&matInvParent, 0, &matParent);
		m_matLocal = m_matWorld * matInvParent;
	}
	
	for each(auto p in m_vecChild)
	{
		p->CalcOriginLocalTM(this);
	}
}

void cFrame::LocalTranslation( IN int nKeyFrame, OUT D3DXMATRIXA16& matT )
{
	D3DXMatrixIdentity(&matT);

	if(m_vecPosTrack.empty())
	{
		matT._41 = m_matLocal._41;
		matT._42 = m_matLocal._42;
		matT._43 = m_matLocal._43;
	}
	else 
	{
		if (nKeyFrame <= m_vecPosTrack.front().nKeyFrame)
		{
			matT._41 = m_vecPosTrack.front().v.x;
			matT._42 = m_vecPosTrack.front().v.y;
			matT._43 = m_vecPosTrack.front().v.z;
		}
		else if (nKeyFrame >= m_vecPosTrack.back().nKeyFrame)
		{
			matT._41 = m_vecPosTrack.back().v.x;
			matT._42 = m_vecPosTrack.back().v.y;
			matT._43 = m_vecPosTrack.back().v.z;
		}
		else
		{
			int nNext = 0;
			for (size_t i = 0; i < m_vecPosTrack.size(); ++i)
			{
				if (nKeyFrame < m_vecPosTrack[i].nKeyFrame)
				{
					nNext = i;
					break;
				}
			}
			int nPrev = nNext - 1;
			float t = (nKeyFrame - (float)m_vecPosTrack[nPrev].nKeyFrame)
				/ (m_vecPosTrack[nNext].nKeyFrame - (float)m_vecPosTrack[nPrev].nKeyFrame);
			D3DXVECTOR3 v;
			D3DXVec3Lerp(&v, &m_vecPosTrack[nPrev].v, &m_vecPosTrack[nNext].v, t);
			matT._41 = v.x;
			matT._42 = v.y;
			matT._43 = v.z;
		}
	}
}

void cFrame::LocalRotation( IN int nKeyFrame, OUT D3DXMATRIXA16& matR )
{
	D3DXMatrixIdentity(&matR);

	if(m_vecRotTrack.empty())
	{
		matR = m_matLocal;
		matR._41 = 0;
		matR._42 = 0;
		matR._43 = 0;
	}
	else 
	{
		if (nKeyFrame <= m_vecRotTrack.front().nKeyFrame)
		{
			D3DXMatrixRotationQuaternion(&matR, &(m_vecRotTrack.front().q));
		}
		else if (nKeyFrame >= m_vecRotTrack.back().nKeyFrame)
		{
			D3DXMatrixRotationQuaternion(&matR, &(m_vecRotTrack.back().q));
		}
		else
		{
			int nNext = 0;
			for (size_t i = 0; i < m_vecRotTrack.size(); ++i)
			{
				if (nKeyFrame < m_vecRotTrack[i].nKeyFrame)
				{
					nNext = i;
					break;
				}
			}
			int nPrev = nNext - 1;
			float t = (nKeyFrame - (float)m_vecRotTrack[nPrev].nKeyFrame)
				/ (m_vecRotTrack[nNext].nKeyFrame - (float)m_vecRotTrack[nPrev].nKeyFrame);
			
			D3DXQUATERNION q;
			D3DXQuaternionSlerp(&q, &m_vecRotTrack[nPrev].q, &m_vecRotTrack[nNext].q, t);
			D3DXMatrixRotationQuaternion(&matR, &q);
		}
	}
}
