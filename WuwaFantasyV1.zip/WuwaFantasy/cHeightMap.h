#pragma once

#include "iMap.h"

class cHeightMap : public iMap
{
private:
	LPD3DXMESH					m_pMesh;
	D3DMATERIAL9				m_stMtl;
	std::vector<D3DXVECTOR3>	m_vecVertex;
	int							m_nHPixel;

	SYNTHESIZE(int, m_nBytePerPixel, BytePerPixel);
	SYNTHESIZE_ADD_REF(LPDIRECT3DTEXTURE9, m_pTexture, Texture);

public:
	cHeightMap(void);
	virtual ~cHeightMap(void);

	virtual void Load(char* szFullPath, D3DXMATRIXA16* mat) override;
	virtual void Render() override;
	virtual bool CalcHeight(float x, float& y, float z) override;
};

