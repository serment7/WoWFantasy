#include "StdAfx.h"
#include "cMainGame.h"
#include "cCamera.h"
#include "cGrid.h"
#include "cPlayer.h"
#include "cPyramid.h"
#include "cAction.h"
#include "cActionMove.h"
#include "cActionSeq.h"
#include "cActionRepeat.h"
#include "cObjLoader.h"
#include "cGroup.h"
#include "cObjMap.h"
#include "cAseLoader.h"
#include "cFrame.h"
#include "cHeightMap.h"

cMainGame::cMainGame(void)
	: m_pCamera(NULL)
	, m_pGrid(NULL)
	, m_pPlayer(NULL)
	, m_pMap(NULL)
	, m_pRoot(NULL)
	, m_dwMesh(0)
	, m_dwGroup(0)
{

}

cMainGame::~cMainGame(void)
{
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pGrid);
	SAFE_DELETE(m_pPlayer);
	SAFE_DELETE(m_pMap);

	SAFE_RELEASE(m_pObjMesh);

	for each(auto p in m_vecPyramid)
	{
		SAFE_RELEASE(p);
	}

	for each(auto p in m_vecMtlTex)
	{
		SAFE_RELEASE(p);
	}

	for each(auto p in m_vecGroup)
	{
		SAFE_RELEASE(p);
	}
	if (m_pRoot)
		m_pRoot->Destroy();
	m_pRoot = NULL;
	g_pObjectManager->Destroy();
	g_pTextureManager->Destroy();
	g_pDeviceManager->Destroy();
}

void cMainGame::Setup()
{

	D3DXMATRIXA16 matWorld, matS, matR, matT;
	D3DXMatrixScaling(&matS, 0.01f, 0.01f, 0.01f);
	D3DXMatrixRotationX(&matR, -D3DX_PI / 2.0f);
	matWorld = matS * matR;

	//cObjLoader l;
	//l.Load("./obj/Map.obj", m_vecGroup, &matWorld);
	//m_pObjMesh = l.Load("./obj/Map.obj", m_vecMtlTex, &matWorld);

	cHeightMap* pMap = new cHeightMap;
	pMap->Load("./HeightMapData/HeightMap.raw", NULL);
	pMap->SetTexture(g_pTextureManager->GetTexture("./HeightMapData/terrain.jpg"));
	m_pMap = pMap;

	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);

	m_pCamera = new cCamera;
	m_pCamera->Setup();

	m_pGrid = new cGrid;
	m_pGrid->Setup();

	m_pPlayer = new cPlayer;
	m_pPlayer->Setup();

	D3DXVECTOR3 p(10, 0, 0);
	D3DCOLOR c = D3DCOLOR_XRGB(255, 255, 0);
	D3DXMatrixRotationY(&matR, D3DX_PI / 3.0f);
	for (int i = 0; i < 6; ++i)
	{
		m_vecHexagon.push_back(ST_PC_VERTEX(p, c));
		D3DXVec3TransformCoord(&p, &p, &matR);
		m_vecHexagon.push_back(ST_PC_VERTEX(p, c));
	}


	cPyramid* pPyramid = NULL;

	D3DXMatrixTranslation(&matT, 0, 0, 1);
	D3DXMatrixScaling(&matS, 0.2f, 2.f, 0.2f);
	D3DXMatrixRotationX(&matR, D3DX_PI / 2.0f);
	matWorld = matS * matR * matT;

	pPyramid = new cPyramid;
	pPyramid->Setup(&matWorld, D3DXCOLOR(1, 1, 0, 1));
	m_vecPyramid.push_back(pPyramid);

	cActionSeq* pActionSeq = new cActionSeq;


	p = D3DXVECTOR3(10, 0, 0);
	D3DXMatrixRotationY(&matR, -D3DX_PI / 3.0f);
	for (int i = 0; i < 6; ++i)
	{
		cActionMove* pActionMove = new cActionMove;
		pActionMove->SetFrom(p);
		D3DXVec3TransformCoord(&p, &p, &matR);
		pActionMove->SetTo(p);
		pActionMove->SetActionTime(1.f);
		pActionMove->SetOwner(pPyramid);
		pActionMove->SetDelegate(pActionSeq);
		pActionSeq->AddAction(pActionMove);
		SAFE_RELEASE(pActionMove);
	}


	cActionRepeat* pActionRepeat = new cActionRepeat;
	pActionRepeat->SetAction(pActionSeq);
	pPyramid->SetAction(pActionRepeat);
	pActionRepeat->Start();

	pActionSeq->SetDelegate(pActionRepeat);


	SAFE_RELEASE(pActionRepeat);
	SAFE_RELEASE(pActionSeq);

	D3DXVECTOR3 vDir(1, -1, 1);
	D3DXVec3Normalize(&vDir, &vDir);

	D3DLIGHT9 stLight;
	ZeroMemory(&stLight, sizeof(D3DLIGHT9));
	stLight.Type = D3DLIGHT_DIRECTIONAL;
	stLight.Ambient = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	stLight.Diffuse = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	stLight.Specular = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
	stLight.Direction = vDir;

	g_pD3DDevice->SetLight(0, &stLight);
	g_pD3DDevice->LightEnable(0, true);

	g_pD3DDevice->SetRenderState(D3DRS_NORMALIZENORMALS, true);
}

void cMainGame::Update()
{
	g_pTimeManager->Update();

	if (m_pRoot)
	{
		int nKeyFrame = GetTickCount() % (3200 - 640) + 640;
		m_pRoot->Update(nKeyFrame, NULL);
	}

	if (m_pPlayer)
	{
		m_pPlayer->Update(m_pMap);
	}

	for each(auto p in m_vecPyramid)
	{
		p->Update();
	}

	if (m_pCamera)
	{
		m_pCamera->Update(&(m_pPlayer->GetPosition()));
	}
}

void cMainGame::Render()
{
	g_pD3DDevice->Clear(NULL,
		NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_XRGB(47, 121, 112),
		1.0f, 0);

	g_pD3DDevice->BeginScene();

	// �׸��� �׸���.

	if (m_pGrid)
	{
		m_pGrid->Render();
	}

	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);

	D3DXMATRIXA16 matWorld;
	D3DXMatrixIdentity(&matWorld);
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &matWorld);


	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, true);

	D3DXMatrixIdentity(&matWorld);
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &matWorld);

	if (m_pRoot)
		m_pRoot->Render();

	if (m_pMap)
	{
		m_pMap->Render();
	}


	if (m_pPlayer)
	{
		m_pPlayer->Render();
	}



	g_pD3DDevice->EndScene();

	g_pD3DDevice->Present(NULL, NULL, NULL, NULL);
}

void cMainGame::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (m_pCamera)
	{
		m_pCamera->WndProc(hWnd, message, wParam, lParam);
	}
}

void cMainGame::OnActionFinish(cAction* pSender)
{
	int n = 0;
}
