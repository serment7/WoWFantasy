#pragma once

class cCamera;
class cGrid;
class cPlayer;
class cPyramid;
class cGroup;
class iMap;

#include "cMtlTex.h"
#include "cAction.h"

class cFrame;

class cMainGame : public iActionDelegate
{
private:
	cCamera*	m_pCamera;
	cGrid*		m_pGrid;
	cPlayer*	m_pPlayer;
	iMap*		m_pMap;
	cFrame*		m_pRoot;
	LPD3DXMESH	m_pObjMesh;
	DWORD		m_dwMesh;
	DWORD		m_dwGroup;

	std::vector<cMtlTex*>		m_vecMtlTex;
	std::vector<cGroup*>		m_vecGroup;
	std::vector<ST_PC_VERTEX>	m_vecHexagon;
	std::vector<cPyramid*>		m_vecPyramid;

public:
	cMainGame(void);
	~cMainGame(void);

	void Setup();
	void Update();
	void Render();
	void WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	/*virtual void foo() = 0;*/

	virtual void OnActionFinish(cAction* pSender) override;
};

