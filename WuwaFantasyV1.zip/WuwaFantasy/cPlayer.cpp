#include "StdAfx.h"
#include "cPlayer.h"
#include "cPyramid.h"

cPlayer::cPlayer(void)
	: m_pPyramid(NULL)
	, m_vDir(0, 0, 1)
	, m_fSpeed(0.1f)
	, m_fAngle(0.0f)
{
}

cPlayer::~cPlayer(void)
{
	SAFE_RELEASE(m_pPyramid);
}

void cPlayer::Setup()
{
	D3DXMATRIXA16 mat, matS, matR, matT;
	
	D3DXMatrixScaling(&matS, 0.2, 1, 0.2);
	D3DXMatrixTranslation(&matT, 0, 0.5, 0);
	D3DXMatrixRotationX(&matR, D3DX_PI / 2.0f);
	
	mat = matS * matT * matR;
	m_pPyramid = new cPyramid;
	m_pPyramid->Setup(&mat, D3DCOLOR_XRGB(255, 255, 255));
}

void cPlayer::Update(iMap* pMap /*= NULL*/)
{
	if (GetKeyState('A') & 0x8000)
	{
		m_fAngle -= 0.1f;
	}
	else if (GetKeyState('D') & 0x8000)
	{
		m_fAngle += 0.1f;
	}

	m_vDir = D3DXVECTOR3(0, 0, 1);
	D3DXMATRIXA16 matR, matT;
	D3DXMatrixRotationY(&matR, m_fAngle);
	D3DXVec3TransformNormal(&m_vDir, &m_vDir, &matR);

	D3DXVECTOR3 vTempPos = m_vPos;
	if (GetKeyState('W') & 0x8000)
	{
		vTempPos = vTempPos + m_vDir * m_fSpeed;
	}
	else if (GetKeyState('S') & 0x8000)
	{
		vTempPos = vTempPos - m_vDir * m_fSpeed;
	}
	
	if(pMap && pMap->CalcHeight(vTempPos.x, vTempPos.y, vTempPos.z))
	{
		m_vPos = vTempPos;
	}

	D3DXMatrixTranslation(&matT, m_vPos.x, m_vPos.y, m_vPos.z);
	m_matWrold = matR * matT;
}

void cPlayer::Render()
{
	if(m_pPyramid)
	{
		m_pPyramid->SetWorldTM(m_matWrold);
		m_pPyramid->Render();
	}
}
