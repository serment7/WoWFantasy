#pragma once

class cBullet;
class cPyramid;

class cPlayer
{
private:
	cPyramid*	m_pPyramid;

	D3DXVECTOR3	m_vDir;
	
	float		m_fSpeed;
	float		m_fAngle;

	SYNTHESIZE_PASS_BY_REF(D3DXVECTOR3,	m_vPos, Position);
	SYNTHESIZE_PASS_BY_REF(D3DXMATRIXA16, m_matWrold, WorldTM);

public:
	cPlayer(void);
	~cPlayer(void);

	void Setup();
	void Update(iMap* pMap = NULL);
	void Render();
};

