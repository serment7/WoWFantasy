#pragma once

class cPyramid : public cGameObject
{
private:
	std::vector<ST_PN_VERTEX>	m_vecVertex;
	D3DMATERIAL9				m_stMtl;

public:
	cPyramid(void);
	virtual ~cPyramid(void);

	virtual void Setup(D3DXMATRIXA16* mat, D3DXCOLOR c);
	virtual void Update() override;
	virtual void Render() override;
};

