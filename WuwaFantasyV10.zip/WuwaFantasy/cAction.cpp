#include "stdafx.h"
#include "cAction.h"
#include"cGameObject.h"
#include"cStatus.h"
#include "cRandom.h"
#include "cSkill.h"

cAction::cAction(cGameObject * _pOwner)
{
	m_pOwner = _pOwner;
	m_entityID = m_pOwner->GetID();
}

cAction::~cAction()
{
}

cGameObject * cAction::GetOwner()
{
	return m_pOwner;
}

void cAction::SetOwner(cGameObject * _pOwner)
{
	m_pOwner = _pOwner;
}

cGameObject * cAction::GetTarget()
{
	return m_pTarget;
}

void cAction::SetTarget(cGameObject * _pTarget)
{
	m_pTarget = _pTarget;
}

void cAction::ReadyMoveTo(const D3DXVECTOR3 & _vTo)
{
	const cStatus& status = m_pOwner->GetStatus();
	m_vFrom = m_pOwner->GetVPos();
	m_vTo = _vTo;
	m_fActionTime = (D3DXVec3Length(&(m_vTo - m_vFrom)) + 0.001f) / (status.GetSpeed());

	HeadTo();
}

void cAction::MoveTo()
{
	if (!m_bAction)
		return;

	m_fPassedTime += g_pTimeManager->GetDeltaTime();

	if (m_fPassedTime < m_fActionTime)
	{
		float t = m_fPassedTime / m_fActionTime;
		D3DXVECTOR3 velocity = (1.0f - t) * m_vFrom + t * m_vTo;
		m_pOwner->SetVPos(velocity);
	}
	else
	{
		if(m_pOwner)
			m_pOwner->SetVPos(m_vTo);
		if (m_pDelegate)
			m_pDelegate->OnActionDelegate(this);
	}
}

void cAction::ReadyHeadTo(const D3DXVECTOR3 & _vTo)
{
	if (m_pOwner)
	{
		m_vFrom = m_pOwner->GetVPos();
		m_vTo = _vTo;
	}
}

void cAction::HeadTo()
{
	if (m_pOwner)
	{
		D3DXVECTOR3 vTargetDir = m_vTo - m_vFrom;

		m_pOwner->SetVDir(vTargetDir);
	}
}

void cAction::ReadyPatrol(const D3DXVECTOR3 & _vCenter)
{
	m_fSenseDistance = 5.0f;
	m_fChaseRange = 20.0f;
	m_sphere.fRadius = 3.0f;
	m_sphere.vCenter = _vCenter;
}

void cAction::Patrol()
{
	if (!m_bAction)
		return;
	m_fPassedTime += g_pTimeManager->GetDeltaTime();
	if (m_fPassedTime>m_fPatrolTime)
	{
		D3DXVECTOR3 velocity=D3DXVECTOR3(0,0,0);
		cRandom::GetVectorInCircle(velocity, m_sphere.fRadius);
		ReadyMoveTo(m_sphere.vCenter+velocity);
		m_fPassedTime = 0.0f;
	}
	MoveTo();
}

void cAction::ReadyAttack(cSkill * _pSkill)
{
	if (m_pSkill)
		m_pSkill->Stop();
	m_pSkill = _pSkill;
	m_fDistance = m_pSkill->GetDistance();
}

void cAction::Attack()
{
	if (!m_bAction&&m_bSkillStart)
		return;

	D3DXVECTOR3 vLength = m_pTarget->GetVPos() - m_pOwner->GetVPos();
	float distance = D3DXVec3LengthSq(&vLength);
	
	
	if (distance > m_fDistance*m_fDistance)
	{
		ReadyMoveTo(m_pTarget->GetVPos());
		MoveTo();
	}
	else
	{
		m_pSkill->Start();
		m_bSkillStart = true;
		m_pOwner->SetVDir(vLength);
	}
}

void cAction::OnSkillDelegate(cSkill * _pSender)
{
	m_bSkillStart = false;
	m_pSkill->Stop();
	if (m_pDelegate)
		m_pDelegate->OnActionDelegate(this);
}

void cAction::Start()
{
	m_bAction = true;
	m_fPassedTime = 0.0f;
}

void cAction::Stop()
{
	m_bAction = false;
}

void cAction::SetDelegate(cActionDelegate * _pDelegate)
{
	m_pDelegate = _pDelegate;
}

void cAction::SetFrom(const D3DXVECTOR3 & _from)
{
	m_vFrom = _from;
}

void cAction::SetTo(const D3DXVECTOR3 & _to)
{
	m_vTo = _to;
}

void cAction::SetActionTime(const float & _actiontime)
{
	m_fActionTime = _actiontime;
}
