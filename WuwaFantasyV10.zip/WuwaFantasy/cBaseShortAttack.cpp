#include "stdafx.h"
#include "cBaseShortAttack.h"
#include "cGameObject.h"

cBaseShortAttack::cBaseShortAttack(const float& _skilldistance,const float& _attackTiming,const float& _attackPeriod)
{
	SetDistance(_skilldistance);
	m_fAttackTiming = _attackTiming;
	m_fAttackPeriod = _attackPeriod;
}


cBaseShortAttack::~cBaseShortAttack()
{
}

void cBaseShortAttack::Start()
{
	if (!(GetTarget() && (0<GetTarget()->GetStatus().GetCurrentHP())))
		return;

	m_entityID = GetOwner()->GetID();
	m_fPassedTime = 0.0f;
	SetCast(true);
}

void cBaseShortAttack::Update(const float & _delta)
{
	SetEffectValue(GetOwner()->GetStatus().GetAttackDamage());

	if (IsCast())
	{
		if (m_fPassedTime > m_fAttackPeriod)
		{
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_AttackEnd, NULL);
			SetCast(false);
			m_bAttack = false;
		}
		else if (!m_bAttack && m_fPassedTime > m_fAttackTiming)
		{
			m_bAttack = true;
			packet_hit = new Packet_Hit(GetEffectValue());
			g_pMessageDispatcher->Dispatch(m_entityID,GetTarget()->GetID(),0.0f,Msg_Hit,packet_hit);
			m_fCoolDownPassedTime = 0.0f;
		}
		else
		{
			m_fPassedTime += _delta;
		}
	}
	else if (IsCoolDown())
	{
		if (m_fCoolDownPassedTime > m_fCoolDownTime)
		{
			SetCoolDown(false);
		}
		else
		{
			m_fCoolDownPassedTime += _delta;
		}
	}
}

void cBaseShortAttack::Render()
{
}

void cBaseShortAttack::Stop()
{
	SetCast(false);
}
