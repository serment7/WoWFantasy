#include "stdafx.h"
#include "cBattleRoar.h"


cBattleRoar::cBattleRoar()
{
}


cBattleRoar::~cBattleRoar()
{
}

void cBattleRoar::Start()
{
	SetCast(true);
}

void cBattleRoar::Update(const float & _delta)
{

}

void cBattleRoar::Render()
{
}

void cBattleRoar::Stop()
{
	SetCast(false);
}
