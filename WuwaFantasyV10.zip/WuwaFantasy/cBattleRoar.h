#pragma once
#include "cSkill.h"
class cBattleRoar :
	public cSkill
{
private:

public:
	cBattleRoar();
	virtual ~cBattleRoar();

	virtual void		Start();
	virtual void		Update(const float& _delta);
	virtual void		Render();
	virtual void		Stop();
};

