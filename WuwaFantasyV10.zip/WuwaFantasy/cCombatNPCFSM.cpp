#include "stdafx.h"
#include "cCombatNPCFSM.h"
#include "cCombatNPCState.h"
#include "cIdleState.h"

cCombatNPCFSM::cCombatNPCFSM(cGameObject* _pOwner, cIState* _pState)
{
	m_pOwner = _pOwner;
	SetGlobalState(new cCombatNPCState(_pState));
	SetCurrentState(cIdleState::GetInstance());
}


cCombatNPCFSM::~cCombatNPCFSM()
{
}

void cCombatNPCFSM::Setup()
{
	GlobalState()->EnterState(m_pOwner);
	CurrentState()->EnterState(m_pOwner);
}
