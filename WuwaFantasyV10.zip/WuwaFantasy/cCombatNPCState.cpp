#include "stdafx.h"
#include "cCombatNPCState.h"
#include "cGameObject.h"
#include "cUITextView.h"
#include "cSkill.h"

cCombatNPCState::cCombatNPCState(cIState* _pState)
{
	m_pState = _pState;
	ZeroMemory(&m_packet, sizeof(m_packet));
	m_packet.msg_type = Msg_IdleAni;
}


cCombatNPCState::~cCombatNPCState()
{
	SAFE_DELETE(m_pState);
	for (auto iter = m_mapSkill.begin(); iter != m_mapSkill.end(); ++iter)
	{
		SAFE_DELETE(iter->second);
	}
	m_mapSkill.clear();
}

void cCombatNPCState::EnterState(cGameObject * _entity)
{
	ZeroMemory(&m_packet, sizeof(m_packet));
	m_pStatus = &_entity->GetStatus();
	m_entityID = _entity->GetID();

	m_pState->EnterState(_entity);
	cEntityState::EnterState(_entity);
	m_pNameText->SetTextColor(D3DCOLOR_XRGB(255, 255, 255));
}

void cCombatNPCState::ExitState(cGameObject * _entity)
{
	m_pState->ExitState(_entity);
}

void cCombatNPCState::Execute(cGameObject * _entity)
{
	m_vCurPos = _entity->GetVPos();
	m_nWeightNum = -1;
	if (m_pLeader)
	{
		m_vLeaderPos = m_pLeader->GetVPos();
		float distance = D3DXVec3LengthSq(&(m_vCurPos - m_vLeaderPos));
		if (distance > KEEP_MAX_DISTANCE*KEEP_MAX_DISTANCE)
		{
			_entity->SetVPos(m_vLeaderPos);
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_Idle, NULL);
		}
		else if (distance > REACTION_DISTANCE*REACTION_DISTANCE)
		{
			m_vLeaderDir = m_pLeader->GetVDir();
			D3DXVec3Normalize(&m_vLeaderDir, &m_vLeaderDir);
			m_vLeaderDir *= (m_pStatus->GetSpeed());
			packet_move = new Packet_Pos(m_vCurPos + m_vLeaderDir);
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_Move, packet_move);
		}
		else if (distance < KEEP_MIN_DISTANCE*KEEP_MIN_DISTANCE)
		{
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_Idle, NULL);
		}
	}

	if (m_bCombat)
	{
		if (m_bCanAttack)
		{

		}
		else
		{
			/*packet_approach = new Packet_Approach(m_pTarget, m_pStatus->GetAttackRange());
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_Approach, packet_approach);*/
		}
	}
}

bool cCombatNPCState::OnMessage(cGameObject * _entity, const ST_PACKET & _packet)
{
	switch (_packet.msg_type)
	{
	case Msg_LostTarget:
		m_pTarget = nullptr;
		m_bCombat = false;
		return true;
	case Msg_SetSkill:
		packet_setskill = (Packet_SetSkill*)_packet.info;
		packet_setskill->skill->SetOwner(_entity);
		m_mapSkill.insert(std::pair<char, cSkill*>(packet_setskill->key, packet_setskill->skill));
		SAFE_DELETE(packet_setskill);
		return true;
	case Msg_NeedHeal:
		for (auto iter = m_mapSkill.begin(); iter != m_mapSkill.end(); ++iter)
		{
			if (iter->second->GetSKillType() == skilltype::Heal)
			{
				if (m_nWeightNum < iter->second->GetEffectValue())
				{
					m_nWeightNum = iter->second->GetEffectValue();
					m_chWeightKey = iter->first;
				}
			}
		}
		if (m_nWeightNum != -1)
		{
			CastSkill(m_chWeightKey);
		}
		return true;
	case Msg_JoinParty:
		m_vecParty.push_back(g_pObjectManager->FindObjectByID(_packet.sender));
		if (!m_pLeader)
			m_pLeader = m_vecParty.front();
		return true;
	case Msg_Target:
		if (m_bLive)
			packet_target = (Packet_Target*)_packet.info;
		m_pTarget = packet_target->pTarget;
		if (0 < m_pTarget->GetStatus().GetCurrentHP())
		{
			Attack(_entity);
			m_bCombat = true;
		}
		SAFE_DELETE(packet_target);
		return true;
	case Msg_AttackEnd:
		if (!m_pTarget)
			return true;
		m_bAttack = false;
		if (0 < m_pTarget->GetStatus().GetCurrentHP())
		{
			Attack(_entity);
		}
		else
		{
			m_pTarget = nullptr;
			m_bCombat = false;
			m_bCoolDown = false;
			m_fPassedSkillTime = 0.0f;
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_IdleAni, NULL);
		}
		return true;
	case Msg_Hit:
		packet_hit = (Packet_Hit*)_packet.info;

		SAFE_DELETE(packet_hit);
		return true;
	default:
		return m_pState->OnMessage(_entity, _packet);
	}
	return false;
}

void cCombatNPCState::Attack(cGameObject * _entity)
{
	if (m_fPassedSkillTime > m_fPerSkill)
	{
		auto iter = m_mapSkill.begin();
		while (iter != m_mapSkill.end())
		{
			if (iter->second->CanUse())
			{
				m_pCurSkill = iter->second;
				m_pCurSkill->Start();
			}
			++iter;
		}

		m_fPassedSkillTime = 0.0f;
	}
	m_packet.msg_type = Msg_AttackAni;
	m_pState->OnMessage(_entity, m_packet);
	g_pMessageDispatcher->Dispatch(_entity->GetID(), _entity->GetID(),
		0.0f, Msg_Standby, packet_target);
}
