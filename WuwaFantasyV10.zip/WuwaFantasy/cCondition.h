#pragma once

class cGameObject;

class cCondition
{
private:
	cGameObject*			m_pOwner = nullptr;
	std::string				m_strConditionName;

public:
	cCondition();
	virtual ~cCondition();

	void			SetOwner(cGameObject* _pOwner);
	cGameObject*	GetOwner() const;
	virtual void	Update(const float& _delta,bool& _lifeTime);
	virtual void	Render();
};

