#include "stdafx.h"
#include "cDworfMageState.h"
#include "cGameObject.h"
#include "cBaseShortAttack.h"

cDworfMageState::cDworfMageState()
{
}

cDworfMageState::~cDworfMageState()
{
}

void cDworfMageState::EnterState(cGameObject * _entity)
{
	_entity->GetChrSkinnedMesh()->SetFolderName(MODEL_PATH + "DworfBattleMage");
	_entity->GetChrSkinnedMesh()->Load("DworfBattleMage.X");
	_entity->GetObjSkinnedMesh()->Load(std::string(MODEL_PATH+"hand/right").c_str(),"righthand.X" ,_entity->GetChrSkinnedMesh(), "LThumb");
	
	m_entityID = _entity->GetID();
	
	_entity->GetStatus().SetAttackDamage(5);

	m_pOwner = _entity;

	m_pAniController = _entity->GetChrSkinnedMesh()->GetAnimationController();
	cStatus* pStatus = &_entity->GetStatus();
	pStatus->SetSpeed(5.0f);
	pStatus->SetMaxHP(100);
	pStatus->SetCurrentHP(100);
	pStatus->SetMaxMP(100);
	pStatus->SetCurrentMP(100);
	pStatus->SetAttackDamage(5);
	m_chrmesh = _entity->GetChrSkinnedMesh();

	SetupAnimation(13);

	float fAttackPeriod = m_chrmesh->GetAnimationPeriod(13);
	packet_setskill = new Packet_SetSkill(VK_RBUTTON, new cBaseShortAttack(2.0f, fAttackPeriod*0.5f, fAttackPeriod));
	g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_SetSkill, packet_setskill);

	SetupAnimation(20);

	_entity->SetBoundSphere(1, D3DXVECTOR3(0, 0, 0));
}

void cDworfMageState::ExitState(cGameObject * _entity)
{
}

void cDworfMageState::Execute(cGameObject * _entity)
{
	m_pAniController->GetTrackDesc(0, &m_desc);
	m_fPassedAnitime += g_pTimeManager->GetDeltaTime();

	float f = m_fPassedAnitime / m_fCurPeriod;
	if (!m_bLive)
	{
		if (m_fPassedAnitime > m_fPeriod - 0.1f)
		{
			m_pAniController->SetTrackPosition(0, m_fPeriod - 0.1f);
		}
	}
	else if (m_bAttack)
	{
		if (m_fPassedAnitime > m_fPeriod - 0.1f)
		{
			m_pAniController->SetTrackPosition(0, 0.0f);
			m_bAttack = false;
		}
	}
}

bool cDworfMageState::OnMessage(cGameObject * _entity, const ST_PACKET & _packet)
{
	//idle20,move34,attack13
	switch (_packet.msg_type)
	{
	case Msg_IdleAni:
		SetupAnimation(20);
		m_bAttack = false;
		return true;
	case Msg_MoveAni:
		SetupAnimation(34);
		m_bAttack = false;
		return true;
	case Msg_AttackAni:
		SetupAnimation(13);
		m_bAttack = true;
		return true;
	case Msg_CastingAni:
		SetupAnimation(17);
		m_bAttack = false;
		return true;
	case Msg_StunAni:
		SetupAnimation(29);
		m_bAttack = false;
		return true;
	case Msg_Death:
		SetupAnimation(32);
		m_bAttack = false;
		m_bLive = false;
		return true;
	
	}
	return false;
}