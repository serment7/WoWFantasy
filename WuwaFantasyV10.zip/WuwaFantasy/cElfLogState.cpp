#include "stdafx.h"
#include "cElfLogState.h"


cElfLogState::cElfLogState()
{
}


cElfLogState::~cElfLogState()
{
}
