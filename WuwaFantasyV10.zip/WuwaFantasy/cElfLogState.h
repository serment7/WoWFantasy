#pragma once
#include "cEntityState.h"
class cElfLogState :
	public cEntityState
{
public:
	cElfLogState();
	virtual ~cElfLogState();
};

