#include "stdafx.h"
#include "cGnomeHealer.h"
#include "cGameObject.h"
#include "cBaseShortAttack.h"

cGnomeHealer::cGnomeHealer()
{
}


cGnomeHealer::~cGnomeHealer()
{
}

void cGnomeHealer::EnterState(cGameObject * _entity)
{
	_entity->GetChrSkinnedMesh()->SetFolderName(MODEL_PATH + "GnomeFemaleHealer");
	_entity->GetChrSkinnedMesh()->Load("GnomeFemaleHealer.X");
	_entity->GetObjSkinnedMesh()->Load(std::string(MODEL_PATH + "mace").c_str(), "mace.X",  _entity->GetChrSkinnedMesh(), "RFingerPinky");

	m_entityID = _entity->GetID();

	_entity->GetStatus().SetAttackDamage(5);

	m_pOwner = _entity;

	m_pAniController = _entity->GetChrSkinnedMesh()->GetAnimationController();
	cStatus* pStatus = &_entity->GetStatus();
	pStatus->SetSpeed(5.0f);
	pStatus->SetMaxHP(100);
	pStatus->SetCurrentHP(100);
	pStatus->SetMaxMP(100);
	pStatus->SetCurrentMP(100);
	pStatus->SetAttackDamage(5);
	m_chrmesh = _entity->GetChrSkinnedMesh();

	SetupAnimation(6);

	float fAttackPeriod = m_chrmesh->GetAnimationPeriod(6);
	packet_setskill = new Packet_SetSkill(VK_RBUTTON, new cBaseShortAttack(1.0f, fAttackPeriod*0.5f, fAttackPeriod));
	g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_SetSkill, packet_setskill);

	SetupAnimation(2);

	_entity->SetBoundSphere(1, D3DXVECTOR3(0, 0, 0));
}

void cGnomeHealer::ExitState(cGameObject * _entity)
{
}

void cGnomeHealer::Execute(cGameObject * _entity)
{
}

bool cGnomeHealer::OnMessage(cGameObject * _entity, const ST_PACKET & _packet)
{
	switch (_packet.msg_type)
	{
	case Msg_IdleAni:
		SetupAnimation(2);
		return true;
	case Msg_MoveAni:
		SetupAnimation(17);
		return true;
	case Msg_AttackAni:
		SetupAnimation(6);
		return true;
	case Msg_CastingAni:
		SetupAnimation(0);
		return true;
	case Msg_StunAni:
		SetupAnimation(9);
		return true;
	case Msg_Death:
		SetupAnimation(30);
		return true;
	}
	return false;
}
