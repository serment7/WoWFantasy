#pragma once
#include "cModelState.h"
class cGnomeHealer :
	public cModelState
{
private:
	Packet_SetSkill*			packet_setskill;
public:
	cGnomeHealer();
	~cGnomeHealer();

	virtual void EnterState(cGameObject* _entity);
	virtual void ExitState(cGameObject* _entity);
	virtual void Execute(cGameObject* _entity);
	virtual bool OnMessage(cGameObject* _entity, const ST_PACKET& _packet);
};

