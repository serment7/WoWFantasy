#include "stdafx.h"
#include "cHeal.h"


cHeal::cHeal()
{
}


cHeal::~cHeal()
{
}

void cHeal::Update(const float & _delta, bool & _lifeTime)
{
}

void cHeal::Render()
{
}