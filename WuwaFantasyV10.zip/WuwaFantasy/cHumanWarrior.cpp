#include "stdafx.h"
#include "cHumanWarrior.h"
#include "cGameObject.h"
#include "cBaseShortAttack.h"

cHumanWarrior::cHumanWarrior()
{
}


cHumanWarrior::~cHumanWarrior()
{
}

void cHumanWarrior::EnterState(cGameObject * _entity)
{
	_entity->GetChrSkinnedMesh()->SetFolderName(MODEL_PATH + "HumanWarrior");
	_entity->GetChrSkinnedMesh()->Load("HumanWarrior.X");
	_entity->GetObjSkinnedMesh()->Load(std::string(MODEL_PATH + "twohandsword").c_str(), "twohandsword.X",  _entity->GetChrSkinnedMesh(), "RFingerRing");

	m_entityID = _entity->GetID();

	_entity->GetStatus().SetAttackDamage(5);

	m_pOwner = _entity;

	m_pAniController = _entity->GetChrSkinnedMesh()->GetAnimationController();
	cStatus* pStatus = &_entity->GetStatus();
	pStatus->SetSpeed(5.0f);
	pStatus->SetMaxHP(100);
	pStatus->SetCurrentHP(100);
	pStatus->SetMaxMP(100);
	pStatus->SetCurrentMP(100);
	pStatus->SetAttackDamage(5);
	m_chrmesh = _entity->GetChrSkinnedMesh();

	SetupAnimation(9);

	float fAttackPeriod = m_chrmesh->GetAnimationPeriod(9);
	packet_setskill = new Packet_SetSkill(VK_RBUTTON, new cBaseShortAttack(1.0f, fAttackPeriod*0.5f, fAttackPeriod));
	g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_SetSkill, packet_setskill);

	SetupAnimation(15);

	_entity->SetBoundSphere(1, D3DXVECTOR3(0, 0, 0));
}

void cHumanWarrior::ExitState(cGameObject * _entity)
{
}

void cHumanWarrior::Execute(cGameObject * _entity)
{
}

bool cHumanWarrior::OnMessage(cGameObject * _entity, const ST_PACKET & _packet)
{
	switch (_packet.msg_type)
	{
	case Msg_IdleAni:
		SetupAnimation(15);
		return true;
	case Msg_MoveAni:
		SetupAnimation(24);
		return true;
	case Msg_AttackAni:
		SetupAnimation(9);
		return true;
	case Msg_CastingAni:
		SetupAnimation(17);
		return true;
	case Msg_StunAni:
		SetupAnimation(20);
		return true;
	case Msg_Death:
		SetupAnimation(21);
		return true;

	}
	return false;
}
