#pragma once
#include "cModelState.h"
class cHumanWarrior :
	public cModelState
{
private:
	Packet_SetSkill*				packet_setskill = nullptr;
public:
	cHumanWarrior();
	virtual ~cHumanWarrior();

	virtual void EnterState(cGameObject* _entity);
	virtual void ExitState(cGameObject* _entity);
	virtual void Execute(cGameObject* _entity);
	virtual bool OnMessage(cGameObject* _entity, const ST_PACKET& _packet);
};

