#include "stdafx.h"
#include "cIState.h"
#include "cGameObject.h"
#include"cIdleState.h"
#include"cMoveState.h"
#include "cStandbyState.h"
#include "cPatrolState.h"
#include "cAttackState.h"

bool cIState::MessageCatch(cGameObject * _entity, const ST_PACKET & _packet)
{
	switch (_packet.msg_type)
	{
	case Msg_Attack:
		m_pAttackState = cAttackState::GetInstance();
		m_pAttackState->OnMessage(_entity, _packet);
		_entity->GetStateMachine()->ChangeState(m_pAttackState);
		m_pAttackState = nullptr;
		return true;
	case Msg_Patrol:
		m_pPatrolState = cPatrolState::GetInstance();
		m_pPatrolState->OnMessage(_entity,_packet);
		_entity->GetStateMachine()->ChangeState(m_pPatrolState);
		m_pPatrolState = nullptr;
		return true;
	case Msg_Idle:
		m_pIdleState = cIdleState::GetInstance();
		m_pIdleState->OnMessage(_entity, _packet);
		_entity->GetStateMachine()->ChangeState(m_pIdleState);
		m_pIdleState = nullptr;
		return true;
	case Msg_Move:
		m_pMoveState = cMoveState::GetInstance();
		m_pMoveState->OnMessage(_entity, _packet);
		_entity->GetStateMachine()->ChangeState(m_pMoveState);
		m_pMoveState = nullptr;
		return true;
	case Msg_Standby:
		m_pStatdbyState = cStandbyState::GetInstance();
		m_pStatdbyState->OnMessage(_entity, _packet);
		_entity->GetStateMachine()->ChangeState(m_pStatdbyState);
		m_pStatdbyState = nullptr;
		return true;
	}
	return false;
}
