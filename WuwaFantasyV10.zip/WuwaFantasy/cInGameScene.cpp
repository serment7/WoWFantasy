#include "stdafx.h"
#include "cInGameScene.h"
#include "cObject.h"
#include "cHydraState.h"
#include "cMonster.h"
#include "cMap.h"
#include "cUIButton.h"
#include "cUIObject.h"
#include "cUIImageView.h"
#include "cUITextView.h"
#include "cRandom.h"
#include "cLichOfKingState.h"
#include "cCombatNPC.h"
#include "cGnomeHealer.h"
#include "cNamedMonster.h"
#include "cDworfMageState.h"
#include "cHumanWarrior.h"
#include "cScorpionState.h"
#include "cSkyBox.h"

cInGameScene::cInGameScene()
	: m_bPaused(FALSE)
	, m_fPlayTime(0.0f)
	, m_pGrid(nullptr)
	, m_pCamera(nullptr)
	, m_nSoundVolume(0)

{

}

cInGameScene::~cInGameScene()
{
	SAFE_RELEASE(m_pFont);
	SAFE_RELEASE(m_pSprite);
	if (m_pUIRoot)
	{
		m_pUIRoot->Destroy();
		m_pUIRoot = NULL;
	}
	g_pObjectManager->Destroy();
	g_pFontManager->Destroy();
}

void cInGameScene::Update()
{
	if (m_bPaused)
		return;

	g_pTimeManager->Update();
	g_pMessageDispatcher->Update();
	g_pGameManager->Update();

	if (m_pUIRoot)
	{
		m_pUIRoot->Update();
	}


	if (m_pPlayer) m_pPlayer->Update();



	if (m_pSkyBox) m_pSkyBox->Update();
	
	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Update();
	}

	g_pUserHUD->Update();

}

void cInGameScene::Render()
{
	g_pD3DDevice->Clear(NULL,
		NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_XRGB(47, 121, 112),
		//D3DCOLOR_XRGB(0, 0, 255),
		1.0f, 0);
	g_pD3DDevice->BeginScene();
	g_pD3DDevice->LightEnable(0, true);
	g_pD3DDevice->LightEnable(1, false);

	g_pD3DDevice->SetFVF(ST_PNT_VERTEX::FVF);

	std::vector<cMap*>& maps = g_pGameManager->GetMap();
	for (size_t i = 0; i < maps.size(); ++i)
	{
		maps[i]->Render();
	}

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Render();
		g_pMessageDispatcher->Dispatch(m_vecObject[i]->GetID(), m_vecObject[i]->GetID(), 0.0f, Msg_Render, NULL);
	}
	if (m_pGrid) m_pGrid->Render();
	if (m_pPlayer) m_pPlayer->Render();

	if (m_pUIRoot)
		m_pUIRoot->Render(m_pSprite);
	if (m_pSkyBox) m_pSkyBox->Render();

	g_pUserHUD->Render();

	g_pMessageDispatcher->Dispatch(g_pGameManager->GetPlayerID(), g_pGameManager->GetPlayerID(), 0.0f, Msg_Render, NULL);

	g_pD3DDevice->EndScene();
	g_pD3DDevice->Present(NULL, NULL, NULL, NULL);
}

void cInGameScene::EnterScene()
{

	D3DXCreateSprite(g_pD3DDevice, &m_pSprite);

	m_pSkyBox = new cSkyBox;
	m_pSkyBox->Initialize();

	g_pKeyManager->Setup();
	m_pCamera = g_pGameManager->GetCamera();

	g_pSoundManager->AddSound("knife_attack1", "knife_slash1.wav");
	g_pSoundManager->AddSound("knife_hit", "knife_hit1.wav");
	g_pSoundManager->AddSound("cursor", "Cursor1.wav");
	g_pSoundManager->AddSound("hit", "hit1.wav"); 
	g_pSoundManager->AddSound("Blizzard", "Blizzard.wav");

	RECT rc;
	GetClientRect(g_hWnd, &rc);
	m_pCamera->SetAspect(rc.right / (float)rc.bottom);

	cGameObject* npc = new cCombatNPC("�������",D3DXVECTOR3(-0, 0, 0),new cGnomeHealer);

	m_vecObject.push_back(npc);

	npc = new cCombatNPC("������", D3DXVECTOR3(2, 0, 0), new cHumanWarrior);

	m_vecObject.push_back(npc);
	
	m_pPlayer = new cPlayer("Ǫ�����ǹ��",D3DXVECTOR3(0,0,0),new cDworfMageState);
	
	g_pGameManager->SetPlayerID(m_pPlayer->GetID());
	g_pUserHUD->EnterScene();
	m_pPlayer->Setup();

	m_pGrid = new cGrid;
	
	m_pGrid->SetTag(g_pGameManager->FindObjectType("collider"));
	g_pObjectManager->AddObject(m_pGrid);
	m_pGrid->Setup();
	
	//cGameObject* monster = new cHydra;
	cGameObject* monster = new cMonster("�������", D3DXVECTOR3(-15, 0, -15),new cHydraState);
	m_vecObject.push_back(monster);
	//monster = new cMonster("�����", D3DXVECTOR3(-15, 0, 15),new cHydraState);
	//m_vecObject.push_back(monster);
	//monster = new cMonster("���ڿ��ǿ�", D3DXVECTOR3(15, 0, -15), new cScorpionState);
	//m_vecObject.push_back(monster);
	//monster = new cMonster("�����콺��", D3DXVECTOR3(15, 0, 15),new cScorpionState);
	//m_vecObject.push_back(monster);
	monster = new cNamedMonster("������ ��ġ��", D3DXVECTOR3(10, 0, 10), new cKingOfLichState);
	m_vecObject.push_back(monster);

	g_pUserHUD->RegisterObjectOnMinimap(m_pPlayer);

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Setup();
		g_pUserHUD->RegisterObjectOnMinimap(m_vecObject[i]);
	}
	
	ZeroMemory(&m_light, sizeof(m_light));
	m_light.Type = D3DLIGHT_DIRECTIONAL;
	m_light.Direction=D3DXVECTOR3(0, 0, 1);
	D3DCOLORVALUE color;
	color.a = color.b = color.g = color.r = 255.0;
	m_light.Ambient = m_light.Diffuse = m_light.Specular = color;
	g_pD3DDevice->SetLight(0, &m_light);
	m_light.Direction = D3DXVECTOR3(0, 0, -1);
	g_pD3DDevice->SetLight(1, &m_light);

	//g_pSoundManager->Start("1");
	
	//g_pGameManager->AddMap(new cMap("output.raw","terrain.png"));
}

void cInGameScene::ExitScene()
{
	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		SAFE_RELEASE(m_vecObject[i]);
	}
	SAFE_RELEASE(m_pPlayer);
	SAFE_RELEASE(m_pGrid);
	SAFE_DELETE(m_pSkyBox);
	g_pUserHUD->ExitScene();
	g_pGameManager->Destroy();
	g_pObjectManager->Destroy();
	g_pTextureManager->Destroy();
	g_pFontManager->Destroy();
	g_pKeyManager->release();
}	

void cInGameScene::ChangeScene(cIScene * _pNextScene)
{
}

void cInGameScene::MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	//static D3DXVECTOR3
	static POINT curPos;
	static bool	bRButtonDown=false;
	switch (iMessage)
	{
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MOUSEMOVE:
		if (bRButtonDown)
		{
			
		}
	case WM_MOUSEWHEEL:
		g_pGameManager->MessageHandle(hWnd, iMessage, wParam, lParam);
		break;
	case WM_RBUTTONDOWN:
		break;
	case WM_RBUTTONUP:
		bRButtonDown = false;
	}
}

enum KeyEnum
{
	SKILL0 = '0'
	, SKILL1
	, SKILL2
	, SKILL3
	, SKILL4
	, SKILL5
	, SKILL6
	, SKILL7
	, SKILL8
	, END
};

void cInGameScene::OnClick(cUIButton* pSender)
{
	/*cUITextView* pTextView = (cUITextView*)m_pUIRoot->GetChildByTag(E_TEXTVIEW);
	if (pSender->GetTag() == E_BUTTON1)
	{
		char* c = "asd";
		pTextView->SetText(c);
	}
	else if (pSender->GetTag() == E_BUTTON2)
	{
		pTextView->SetText("��ư2 ����");
	}
	else if (pSender->GetTag() == E_BUTTON3)
	{
		pTextView->SetText("��ư3 ����");
	}
	else if (pSender->GetTag() == E_BUTTON4)
	{
		pTextView->SetText("��ư4 ����");
	}
	else if (pSender->GetTag() == E_BUTTON5)
	{
		pTextView->SetText("��ư5 ����");
	}
	else if (pSender->GetTag() == E_BUTTON6)
	{
		pTextView->SetText("��ư6 ����");
	}
	else if (pSender->GetTag() == E_BUTTON7)
	{
		pTextView->SetText("��ư7 ����");
	}
	else if (pSender->GetTag() == E_BUTTON8)
	{
		pTextView->SetText("��ư8 ����");
	}
	else if (pSender->GetTag() == E_BUTTON9)
	{
		pTextView->SetText("��ư9 ����");
	}
	else if (pSender->GetTag() == E_BUTTON10)
	{
		pTextView->SetText("��ư10 ����");
	}*/
}