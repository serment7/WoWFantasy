#pragma once
#include "cIScene.h"
#include "cGrid.h"
#include "cPlayer.h"
#include "cCamera.h"
#include "cUIButton.h"

class cGameObject;
class cUIObject;
class cSkyBox;

class cInGameScene : 
	public cIScene, public iUIButtonDelegate
{
private:
	bool			m_bPaused;
	float			m_fPlayTime;
	cGrid*			m_pGrid;
	cCamera*		m_pCamera;
	cPlayer*		m_pPlayer;
	int				m_nSoundVolume;

	std::vector<cGameObject*> m_vecObject;

	D3DLIGHT9		m_light;

	cUIObject*		m_pUIRoot;
	LPD3DXFONT		m_pFont;
	LPD3DXSPRITE	m_pSprite;

	cSkyBox*		m_pSkyBox=nullptr;

	int	PlayerX, PlayerY, PlayerZ;
	int	GnomeX, GnomeY, GnomeZ;
	int	Warrior_X, WarriorY, WarriorZ;

public:
	cInGameScene();
	virtual ~cInGameScene();

	virtual void	Update();
	virtual void	Render();
	virtual void	EnterScene();
	virtual void	ExitScene();
	virtual void	ChangeScene(cIScene* _pNextScene);
	virtual void	MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
	virtual void	OnClick(cUIButton* pSender) override;
};