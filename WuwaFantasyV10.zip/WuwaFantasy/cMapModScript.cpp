#include "stdafx.h"
#include "cMapModScript.h"


cMapModScript::cMapModScript()
{
}


cMapModScript::~cMapModScript()
{
}
