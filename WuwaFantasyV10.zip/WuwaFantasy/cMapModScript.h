#pragma once
#include "cIScript.h"
class cMapModScript :
	public cIScript
{
public:
	cMapModScript();
	virtual ~cMapModScript();
};

