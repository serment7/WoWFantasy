#include "stdafx.h"
#include "cMonsterFSM.h"
#include "cMonsterState.h"
#include "cPatrolState.h"
#include "cGameObject.h"
#include "cAction.h"

cMonsterFSM::cMonsterFSM(cGameObject * _pOwner, cIState * _pState)
{
	m_pOwner = _pOwner;
	SetGlobalState(new cMonsterState(_pState));

	SetCurrentState(cPatrolState::GetInstance());
	m_pOwner->GetAction()->ReadyPatrol(m_pOwner->GetVPos());
	m_pOwner->GetAction()->Start();
}

cMonsterFSM::~cMonsterFSM()
{
}

void cMonsterFSM::Setup()
{
	GlobalState()->EnterState(m_pOwner);
	CurrentState()->EnterState(m_pOwner);
}
