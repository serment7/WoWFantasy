#include "stdafx.h"
#include "cMonsterState.h"
#include "cGameObject.h"
#include "cRandom.h"
#include "cSkill.h"
#include "cUIObject.h"
#include "cUITextView.h"

cMonsterState::cMonsterState(cIState* _pState)
{
	m_pState = _pState;
	ZeroMemory(&m_packet, sizeof(m_packet));
}

cMonsterState::~cMonsterState()
{
}

void cMonsterState::EnterState(cGameObject * _entity)
{
	m_entityID = _entity->GetID();
	
	m_pStatus = &_entity->GetStatus();

	m_vRespawnPos = _entity->GetVPos();

	m_vecTargetTag.push_back(g_pGameManager->FindObjectType("player"));
	m_vecTargetTag.push_back(g_pGameManager->FindObjectType("combatnpc"));
	m_pState->EnterState(_entity);
	cEntityState::EnterState(_entity);
	m_pNameText->SetTextColor(D3DCOLOR_XRGB(255, 0, 0));
	m_fMovePassedTime = cRandom::GetFloat(8.0f,0.0f);
}

void cMonsterState::ExitState(cGameObject * _entity)
{
	m_pState->ExitState(_entity);
}

void cMonsterState::Execute(cGameObject * _entity)
{
	cEntityState::Execute(_entity);

	m_pState->Execute(_entity);

	float delta = g_pTimeManager->GetDeltaTime();

	if (!m_bLive)
	{
		m_fRespawnPassedTime += delta;

		if (m_fRespawnPassedTime > m_fRespawnTime)
		{
			m_bLive = true;
			_entity->SetVPos(m_vRespawnPos);
			m_pStatus->SetCurrentHP(m_pStatus->GetMaxHP());
			m_pStatus->SetCurrentMP(m_pStatus->GetMaxMP());
			m_packet.msg_type= Msg_IdleAni;
			m_pState->OnMessage(_entity, m_packet);
			_entity->SetShow(true);
		}
		else if (m_fRespawnPassedTime > m_fDeathMotionTime)
		{
			_entity->SetShow(false);
		}
		return;
	}

	

	m_fMovePassedTime += delta;

	for (auto i = m_mapSkill.begin(); i != m_mapSkill.end(); ++i)
	{
		i->second->Update(delta);
	}

	m_vPos = _entity->GetVPos();

	if (!m_bCombat)
	{
		for (size_t i = 0; i < m_vecTargetTag.size(); ++i)
		{
			std::vector<cGameObject*>& target = g_pObjectManager->FindObjectByTag(m_vecTargetTag[i]);
			for (size_t i = 0; i < target.size(); ++i)
			{
				m_pTarget = target[i];
				if (!(0 < m_pTarget->GetStatus().GetCurrentHP()))
					continue;
				m_vTargetPos = m_pTarget->GetVPos();
				m_fTargetRange = D3DXVec3LengthSq(&(m_vTargetPos - m_vPos));
				if (m_fTargetRange < m_pStatus->GetSenseRange()*m_pStatus->GetSenseRange())
				{
					m_bCombat = true;
					m_fAttackRange = m_pTarget->GetBoundSphere().fRadius + m_pStatus->GetAttackRange();
				}
				else
					m_pTarget = nullptr;
			}
		}
	}
	else {
		if (!m_pTarget)
		{
			m_bCombat = false;
		}
		else
		{
			m_vTargetPos = m_pTarget->GetVPos();
			m_fTargetRange = D3DXVec3LengthSq(&(m_vTargetPos - m_vPos));
			if (m_fTargetRange > m_pStatus->GetChaseRange()*m_pStatus->GetChaseRange())
			{
				m_bCombat = false;
				m_pTarget = nullptr;
				packet_move = new Packet_Pos(m_vRespawnPos);
				g_pMessageDispatcher->Dispatch(m_entityID, m_entityID,
					0.0f, Msg_Patrol, packet_move);
			}
			else
			{
				if ( m_pTarget && m_mapSkill[BASE_ATTACK]->CanUse())
				{
					packet_attack = new Packet_Attack(m_pTarget,m_mapSkill[BASE_ATTACK]);
					g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_Attack, packet_attack);
				}
			}
		}
	}

	
}

bool cMonsterState::OnMessage(cGameObject * _entity, const ST_PACKET & _packet)
{
	switch (_packet.msg_type) 
	{
	case Msg_SetSkill:
		packet_setskill = (Packet_SetSkill*)_packet.info;
		packet_setskill->skill->SetOwner(_entity);
		m_mapSkill.insert(std::pair<char, cSkill*>(packet_setskill->key, packet_setskill->skill));
		SAFE_DELETE(packet_setskill);
		return true;
	case Msg_AddCondition:
		packet_condition = (Packet_AddCondition*)_packet.info;
		_entity->AddCondition(packet_condition->pCondition);
		SAFE_DELETE(packet_condition);
		return true;
	case Msg_FindTarget:
		packet_target = (Packet_Target*)_packet.info;
		if (!m_pTarget)
		{
			m_pTarget = packet_target->pTarget;
			m_bCombat = true;
		}
		SAFE_DELETE(packet_target);
		return true;
	case Msg_Render:
		if(_entity->IsShow())
			m_pUIRoot->Render(g_pSpriteManager->GetSprite());
		return true;
	case Msg_Hit:
		if (!m_bLive)
			return true;
		g_pSoundManager->Start("hit");
		packet_hit = (Packet_Hit*)_packet.info;
		m_pStatus->DecCurrentHP(packet_hit->damage);
		if (0 < m_pStatus->GetCurrentHP())
		{
			m_vecTargetList.push_back(g_pObjectManager->FindObjectByID(_packet.sender));
			m_fSearchTarget = -1.0f;
			m_searchIndex = -1;
			for (size_t i = 0; i < m_vecTargetList.size(); ++i)
			{
				m_fTargetRange = D3DXVec3LengthSq(&(m_vPos - m_vecTargetList[i]->GetVPos()));
				if (m_fSearchTarget > m_fTargetRange)
				{
					m_fSearchTarget = m_fTargetRange;
					m_searchIndex = i;
				}
			}
			if (m_searchIndex != -1)
			{
				m_pTarget = m_vecTargetList[m_searchIndex];
				m_bCombat = true;
			}
		}
		else
		{
			m_vecTargetList.clear();
			m_pTarget = nullptr;
			m_packet.msg_type = Msg_Death;
			m_pState->OnMessage(_entity, m_packet);
			m_bLive = false;
			m_fRespawnPassedTime = 0.0f;
			m_fRespawnTime = cRandom::GetFloat(8.0, 5.0);
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_Standby, NULL);
		}
		return true;
	case Msg_Attack:
		if (!m_pTarget)
			return true;
		packet_hit = new Packet_Hit(m_pStatus->GetAttackDamage());
		g_pMessageDispatcher->Dispatch(m_entityID, m_pTarget->GetID(), 0.0f, Msg_Hit, packet_hit);
		if (0 < m_pTarget->GetStatus().GetCurrentHP())
		{
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_IdleAni, NULL);
		}
		else
		{
			m_pTarget = nullptr;
			m_bCombat = false;
			g_pMessageDispatcher->Dispatch(m_entityID, m_entityID, 0.0f, Msg_IdleAni, NULL);
		}
		return true;
	default:
		return m_pState->OnMessage(_entity,_packet);
	}
	return false;
}
