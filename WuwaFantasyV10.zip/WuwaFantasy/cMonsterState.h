#pragma once
#include "cEntityState.h"

class cGameObject;
class cStatus;
class cUITextView;

class cMonsterState :
	public cEntityState
{
private:
	std::vector<size_t>	m_vecTargetTag;
	Packet_Pos*		packet_move = nullptr;
	Packet_Hit*			packet_hit = nullptr;
	Packet_Target*		packet_target = nullptr;
	Packet_Attack*		packet_attack = nullptr;
	Packet_AddCondition*	packet_condition=nullptr;
	Packet_SetSkill*	packet_setskill = nullptr;
	ST_PACKET			m_packet;
	
	D3DXVECTOR3			m_vPos = D3DXVECTOR3(0, 0, 0);
	D3DXVECTOR3			m_vTargetPos = D3DXVECTOR3(0, 0, 0);
	float				m_fTargetRange = 0.0f;
	float				m_fSearchTarget = 0.0f;
	size_t				m_searchIndex = 0;
	std::vector<cGameObject*> m_vecTargetList;

	D3DXVECTOR3			m_vRespawnPos = D3DXVECTOR3(0, 0, 0);
	float				m_fRespawnPassedTime = 0.0f;
	float				m_fRespawnTime = 0.0f;
	float				m_fDeathMotionTime = 3.0f;
	float				m_fMovePassedTime = 0.0f;
	float				m_fMovePerTime = 8.0f;
	float				m_fPerMoveAmount = 3.0f;
	
	float				m_fAttackRange = 0.0f;

public:
	cMonsterState(cIState* _pState);
	~cMonsterState();

	virtual void	EnterState(cGameObject* _entity);
	virtual void	ExitState(cGameObject* _entity);
	virtual void	Execute(cGameObject* _entity);
	virtual bool	OnMessage(cGameObject* _entity, const ST_PACKET& _packet);
};

