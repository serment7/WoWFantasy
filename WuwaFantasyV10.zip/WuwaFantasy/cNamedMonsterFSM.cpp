#include "stdafx.h"
#include "cNamedMonsterFSM.h"
#include "cNamedMonsterState.h"
#include "cIdleState.h"

cNamedMonsterFSM::cNamedMonsterFSM(cGameObject* _pOwner, cIState* _pState)
{
	m_pOwner = _pOwner;
	SetGlobalState(new cNamedMonsterState(_pState));

	SetCurrentState(cIdleState::GetInstance());
}


cNamedMonsterFSM::~cNamedMonsterFSM()
{
}

void cNamedMonsterFSM::Setup()
{
	GlobalState()->EnterState(m_pOwner);
	CurrentState()->EnterState(m_pOwner);
}
