#pragma once
#include "cStateMachine.h"
class cNamedMonsterFSM :
	public cStateMachine
{
public:
	cNamedMonsterFSM(cGameObject* _pOwner, cIState* _pState);
	virtual ~cNamedMonsterFSM();

	virtual void Setup();
};

