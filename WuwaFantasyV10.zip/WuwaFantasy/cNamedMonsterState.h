#pragma once
#include "cEntityState.h"

class cNamedMonsterState :
	public cEntityState
{
private:
	D3DXVECTOR3					m_vCurPos;
	D3DXVECTOR3					m_vCurDir;

	std::vector<size_t>	m_vecTargetTag;
	Packet_Pos*		packet_move = nullptr;
	Packet_Hit*			packet_hit = nullptr;
	Packet_Attack*		packet_attack = nullptr;
	Packet_SetSkill*	packet_setskill = nullptr;
	Packet_AddCondition*	packet_condition = nullptr;
	ST_PACKET			m_packet;

	D3DXVECTOR3			m_vTargetPos = D3DXVECTOR3(0, 0, 0);
	float				m_fTargetRange = 0.0f;
	float				m_fSearchTarget = 0.0f;
	size_t				m_searchIndex = 0;
	std::vector<cGameObject*> m_vecTargetList;

	D3DXVECTOR3			m_vRespawnPos = D3DXVECTOR3(0, 0, 0);
	float				m_fRespawnPassedTime = 0.0f;
	float				m_fRespawnTime = 0.0f;
	float				m_fDeathMotionTime = 30.0f;

	float				m_fAttackRange = 0.0f;
	float				m_fRespawnRange = 0.0f;

	float				m_fPerSkill=5.0f;
	float				m_fPassedSkillTime=0.0f;
	bool				m_bAttack=false;
	bool				m_bStun = false;
	bool				m_bCoolDown = false;

public:
	cNamedMonsterState(cIState* _pState);
	virtual ~cNamedMonsterState();

	virtual void		EnterState(cGameObject* _entity);
	virtual void		ExitState(cGameObject* _entity);
	virtual void		Execute(cGameObject* _entity);
	virtual bool		OnMessage(cGameObject* _entity, const ST_PACKET& _packet);
	void				Attack(cGameObject* _entity);
};

