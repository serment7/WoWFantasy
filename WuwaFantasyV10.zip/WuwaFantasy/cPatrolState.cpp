#include "stdafx.h"
#include "cPatrolState.h"
#include "cGameObject.h"
#include "cAction.h"

cPatrolState::cPatrolState()
{
}


cPatrolState::~cPatrolState()
{
}

void cPatrolState::EnterState(cGameObject * _player)
{
	_player->GetAction()->Patrol();
}

void cPatrolState::ExitState(cGameObject * _player)
{
}

void cPatrolState::Execute(cGameObject * _player)
{
	_player->GetAction()->Patrol();
}

bool cPatrolState::OnMessage(cGameObject * _player, const ST_PACKET & _packet)
{
	switch (_packet.msg_type)
	{
	case Msg_Patrol:
		packet_pos = (Packet_Pos*)_packet.info;
		_player->GetAction()->ReadyPatrol(packet_pos->vPos);
		_player->GetAction()->SetDelegate(nullptr);
		_player->GetAction()->Start();
		SAFE_DELETE(packet_pos);
		return true;
	default:
		MessageCatch(_player,_packet);
	}
	return false;
}
