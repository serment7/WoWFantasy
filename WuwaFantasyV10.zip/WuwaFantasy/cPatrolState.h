#pragma once
#include "cIState.h"
class cPatrolState :
	public cIState
{
private:
	Packet_Pos*		packet_pos=nullptr;
public:
	cPatrolState();
	~cPatrolState();

	static cPatrolState* GetInstance()
	{
		static cPatrolState instance;
		return &instance;
	}

	virtual void EnterState(cGameObject* _player);
	virtual void ExitState(cGameObject* _player);
	virtual void Execute(cGameObject* _player);
	virtual bool OnMessage(cGameObject* _player, const ST_PACKET& _packet);
};

