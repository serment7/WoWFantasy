#include "stdafx.h"
#include "cRoar.h"


cRoar::cRoar()
{
}


cRoar::~cRoar()
{
}
