#pragma once
#include "cSkill.h"
class cRoar :
	public cSkill
{
public:
	cRoar();
	virtual ~cRoar();
};

