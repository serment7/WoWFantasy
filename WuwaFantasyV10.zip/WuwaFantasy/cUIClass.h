#pragma once
#include "cInGameScene.h"
#include "cUIButton.h"
#include "cUIObject.h"
#include "cUIImageView.h"
#include "cUITextView.h"


class cUIClass : 
	public iUIButtonDelegate
{
private:
	cUIObject*		m_pUIRoot;
	LPD3DXFONT		m_pFont;
	LPD3DXSPRITE	m_pSprite;
public:
	cUIClass();
	~cUIClass();

	virtual void	Update();
	virtual void	Render();
	virtual void	EnterScene();
	virtual void	ExitScene();
	virtual void	OnClick(cUIButton* pSender) override;
};

