#include "stdafx.h"
#include "cActionSeq.h"


cActionSeq::cActionSeq(void)
	: m_nSeqNo(0)
{
}


cActionSeq::~cActionSeq(void)
{
	for each(auto p in m_vecAction)
	{
		SAFE_RELEASE(p);
	}
}

void cActionSeq::Start()
{
	m_nSeqNo = 0;
	if (m_vecAction.empty())
		return;

	m_vecAction[m_nSeqNo]->Start();
}

void cActionSeq::Update()
{
	if (m_nSeqNo >= m_vecAction.size())
	{
		if (m_pDelegate)
		{
			m_pDelegate->OnActionFinish(this);
		}
	}
	else
	{
		m_vecAction[m_nSeqNo]->Update();
	}
}

void cActionSeq::OnActionFinish( cAction* pSender )
{
	++m_nSeqNo;
	if (m_nSeqNo < m_vecAction.size())
	{
		m_vecAction[m_nSeqNo]->Start();
	}
}
