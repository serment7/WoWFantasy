#pragma once

class cMtlTex;
class cFrame;

class cAseLoader
{
private:
	FILE*	m_fp;
	char	m_szToken[1024];
	cFrame*	m_pRoot;
	std::vector<cMtlTex*> m_vecMtlTex;
	std::map<std::string, cFrame*> m_mapFrame;

public:
	cAseLoader(void);
	~cAseLoader(void);

	cFrame*	Load(char* szFullPath);
	char*	GetToken();
	bool	IsWhite(char c);
	bool	IsEquel(char* str1, char* str2);
	void	SkipBlock();
	int		GetInteger();
	float	GetFloat();

	void	ProcessMATERIAL_LIST();
	void	ProcessMATERIAL(OUT cMtlTex* pMtlTex);
	void	ProcessMAP_DIFFUSE(OUT cMtlTex* pMtlTex);
	cFrame*	ProcessGEOMOBJECT();
	void	ProcessMESH(OUT cFrame* pFrame);
	void	ProcessMESH_VERTEX_LIST(OUT std::vector<D3DXVECTOR3>& vecV);
	void	ProcessMESH_FACE_LIST(OUT std::vector<ST_PNT_VERTEX>& vecVertex, IN std::vector<D3DXVECTOR3>& vecV);
	void	ProcessMESH_TVERTLIST(OUT std::vector<D3DXVECTOR2>& vecVT);
	void	ProcessMESH_TFACELIST(OUT std::vector<ST_PNT_VERTEX>& vecVertex, IN std::vector<D3DXVECTOR2>& vecVT);
	void	ProcessMESH_NORMALS(OUT std::vector<ST_PNT_VERTEX>& vecVertex);
	void	ProcessNODE_TM(OUT cFrame* pFrame);
	void	ProcessTM_ANIMATION(OUT cFrame* pFrame);
	void	ProcessCONTROL_POS_TRACK(OUT cFrame* pFrame);
	void	ProcessCONTROL_ROT_TRACK(OUT cFrame* pFrame);
	
};

