#pragma once

#include "cMtlTex.h"

class cFrame : public cObject
{
protected:
	std::vector<cFrame*> m_vecChild;

protected:
	SYNTHESIZE_PASS_BY_REF(std::vector<ST_POS_SAMPLE>, m_vecPosTrack, PosTrack);
	SYNTHESIZE_PASS_BY_REF(std::vector<ST_ROT_SAMPLE>, m_vecRotTrack, RotTrack);
	SYNTHESIZE_PASS_BY_REF(std::vector<ST_PNT_VERTEX>, m_vecVertex, Vertex);
	SYNTHESIZE_PASS_BY_REF(D3DXMATRIXA16, m_matWorld, WorldTM);
	SYNTHESIZE_PASS_BY_REF(D3DXMATRIXA16, m_matLocal, LocalTM);
	SYNTHESIZE_ADD_REF(cMtlTex*, m_pMtlTex, MtlTex);

public:
	cFrame(void);
	~cFrame(void);
	void Update(int nKeyFrame, cFrame* pParent);
	void Render();
	void AddChild(cFrame* pFrame);
	void Destroy();
	void CalcOriginLocalTM(cFrame* pParent);
	void LocalTranslation(IN int nKeyFrame, OUT D3DXMATRIXA16& matT);
	void LocalRotation(IN int nKeyFrame, OUT D3DXMATRIXA16& matR);
};

