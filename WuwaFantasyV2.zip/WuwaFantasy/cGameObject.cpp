#include "StdAfx.h"
#include "cGameObject.h"


cGameObject::cGameObject(void)
	: m_vPosition(0, 0, 0)
	, m_vDirection(0, 0, 0)
	, m_pAction(NULL)
{
	D3DXMatrixIdentity(&m_matWorld);
}


cGameObject::~cGameObject(void)
{
	SAFE_RELEASE(m_pAction);
}
