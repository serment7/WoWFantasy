#include "StdAfx.h"
#include "cGrid.h"
#include "cPyramid.h"

cGrid::cGrid(void)
	: m_pVB(NULL)
	, m_nNumLine(0)
{
}


cGrid::~cGrid(void)
{
	SAFE_RELEASE(m_pVB);

	for each(auto p in m_vecPyramid)
	{
		SAFE_RELEASE(p);
	}
}

void cGrid::Setup( int nLine /*= 30*/, float fInterval /*= 1.0f*/ )
{
	std::vector<ST_PC_VERTEX>	vecVertex;

	float fNumLine = nLine / 2;

	float fMax = fNumLine * fInterval;

	ST_PC_VERTEX v;
	
	for (int i = 1; i <= fNumLine; ++i)
	{
		if (i % 5 == 0)
		{
			v.c = D3DCOLOR_XRGB(255, 255, 255);
		}
		else
		{
			v.c = D3DCOLOR_XRGB(128, 128, 128);
		}
		v.p = D3DXVECTOR3(-fMax, 0, i * fInterval); vecVertex.push_back(v);
		v.p = D3DXVECTOR3( fMax, 0, i * fInterval); vecVertex.push_back(v);

		v.p = D3DXVECTOR3(-fMax, 0,-i * fInterval); vecVertex.push_back(v);
		v.p = D3DXVECTOR3( fMax, 0,-i * fInterval); vecVertex.push_back(v);

		v.p = D3DXVECTOR3( i * fInterval, 0,-fMax); vecVertex.push_back(v);
		v.p = D3DXVECTOR3( i * fInterval, 0, fMax); vecVertex.push_back(v);

		v.p = D3DXVECTOR3(-i * fInterval, 0,-fMax); vecVertex.push_back(v);
		v.p = D3DXVECTOR3(-i * fInterval, 0, fMax); vecVertex.push_back(v);
	}

	v.c = D3DCOLOR_XRGB(255, 0, 0);
	v.p = D3DXVECTOR3(-fMax, 0, 0); vecVertex.push_back(v);
	v.p = D3DXVECTOR3( fMax, 0, 0); vecVertex.push_back(v);

	v.c = D3DCOLOR_XRGB(0, 255, 0);
	v.p = D3DXVECTOR3( 0,-fMax, 0); vecVertex.push_back(v);
	v.p = D3DXVECTOR3( 0, fMax, 0); vecVertex.push_back(v);

	v.c = D3DCOLOR_XRGB(0, 0, 255);
	v.p = D3DXVECTOR3( 0, 0,-fMax); vecVertex.push_back(v);
	v.p = D3DXVECTOR3( 0, 0, fMax); vecVertex.push_back(v);

	m_nNumLine = vecVertex.size() / 2;

	g_pD3DDevice->CreateVertexBuffer(
		vecVertex.size() * sizeof(ST_PC_VERTEX),
		0,
		ST_PC_VERTEX::FVF,
		D3DPOOL_MANAGED,
		&m_pVB,
		NULL);

	ST_PC_VERTEX* pV;
	m_pVB->Lock(0, 0, (LPVOID*)&pV, 0);
	memcpy(pV, &vecVertex[0], vecVertex.size() * sizeof(ST_PC_VERTEX));
	m_pVB->Unlock();
	

	D3DXMATRIXA16 matR, matS, matWorld;
	
	D3DXMatrixScaling(&matS, 0.2f, 2.f, 0.2f);
	
	//x ��
	D3DXMatrixRotationZ(&matR, D3DX_PI / 2.0f);
	
	matWorld = matS * matR;
	
	cPyramid* pPyramid = new cPyramid;
	pPyramid->Setup(&matWorld, D3DXCOLOR(1, 0 ,0, 1));
	m_vecPyramid.push_back(pPyramid);

	//y ��
	D3DXMatrixRotationZ(&matR, D3DX_PI);

	matWorld = matS * matR;

	pPyramid = new cPyramid;
	pPyramid->Setup(&matWorld, D3DXCOLOR(0, 1 ,0, 1));
	m_vecPyramid.push_back(pPyramid);

	//z ��
	D3DXMatrixRotationX(&matR, -D3DX_PI / 2.0f);

	matWorld = matS * matR;

	pPyramid = new cPyramid;
	pPyramid->Setup(&matWorld, D3DXCOLOR(0, 0 ,1, 1));
	m_vecPyramid.push_back(pPyramid);
}

void cGrid::Render()
{
	g_pD3DDevice->SetTexture(0, 0);

	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);
	
	D3DXMATRIXA16 matWorld;

	D3DXMatrixIdentity(&matWorld);
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &matWorld);

	g_pD3DDevice->SetFVF(ST_PC_VERTEX::FVF);
	g_pD3DDevice->SetStreamSource(0, m_pVB, 0, sizeof(ST_PC_VERTEX));
	g_pD3DDevice->DrawPrimitive(D3DPT_LINELIST, 0, m_nNumLine);

// 	g_pD3DDevice->DrawPrimitiveUP(
// 		D3DPT_LINELIST,
// 		vecVertex.size() / 2,
// 		&vecVertex[0],
// 		sizeof(ST_PC_VERTEX));

	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, true);
	for each(auto p in m_vecPyramid)
	{
		p->Render();
	}
}
