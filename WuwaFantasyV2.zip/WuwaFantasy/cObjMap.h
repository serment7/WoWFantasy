#pragma once

class cObjMap : public iMap
{
private:
	std::vector<D3DXVECTOR3> m_vecVertex;

public:
	cObjMap(void);
	~cObjMap(void);

	virtual void Load(char* szFullPath, D3DXMATRIXA16* mat) override;
	virtual void Render() override;
	virtual bool CalcHeight(float x, float& y, float z) override;
};

