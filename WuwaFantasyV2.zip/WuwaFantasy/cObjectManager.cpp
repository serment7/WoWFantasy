#include "StdAfx.h"
#include "cObjectManager.h"


cObjectManager::cObjectManager(void)
{
}


cObjectManager::~cObjectManager(void)
{
}
