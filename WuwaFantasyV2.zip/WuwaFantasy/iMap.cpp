#include "StdAfx.h"
#include "iMap.h"


iMap::iMap(void)
{
}


iMap::~iMap(void)
{
}
