#pragma once
class iMap
{
public:
	iMap(void);
	virtual ~iMap(void);

	virtual void Load(char* szFullPath, D3DXMATRIXA16* mat) = 0;
	virtual void Render() = 0;
	virtual bool CalcHeight(float x, float& y, float z) = 0;
};

