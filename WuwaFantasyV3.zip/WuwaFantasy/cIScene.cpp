#include "stdafx.h"
#include "cIScene.h"


cIScene::cIScene()
{
}


cIScene::~cIScene()
{
}

void cIScene::ChangeScene(cIScene *)
{
}