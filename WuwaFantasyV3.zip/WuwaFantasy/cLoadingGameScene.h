// cLoadingGameScene.h: interface for the cLoadingGameScene class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

class cLoadingGameScene  
{
public:
	cLoadingGameScene();
	virtual ~cLoadingGameScene();

};
