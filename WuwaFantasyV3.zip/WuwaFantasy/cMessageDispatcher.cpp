#include "stdafx.h"
#include "cMessageDispatcher.h"


cMessageDispatcher::cMessageDispatcher()
{
}


cMessageDispatcher::~cMessageDispatcher()
{
}
