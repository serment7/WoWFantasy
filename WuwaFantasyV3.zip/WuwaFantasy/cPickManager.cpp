#include "stdafx.h"
#include "cPickManager.h"


cPickManager::cPickManager()
{
}


cPickManager::~cPickManager()
{
}
