#pragma once
class cPickManager
{
public:
	cPickManager();
	~cPickManager();
};

