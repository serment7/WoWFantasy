#include "stdafx.h"
#include "cPicking.h"


cPicking::cPicking()
{
}


cPicking::~cPicking()
{
}
