#pragma once

class cPicking
{
public:
	cPicking();
	~cPicking();


};

