#include "stdafx.h"
#include "cStateMachine.h"