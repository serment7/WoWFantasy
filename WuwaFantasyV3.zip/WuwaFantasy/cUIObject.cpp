#include "StdAfx.h"
#include "cUIObject.h"


cUIObject::cUIObject(void)
	: m_pParent(NULL)
	, m_vPosition(0, 0, 0)
	, m_isDebugRender(true)
	, m_nTag(0)
{
	D3DXMatrixIdentity(&m_matWorld);
}


cUIObject::~cUIObject(void)
{
}

void cUIObject::AddChild( cUIObject* pChild )
{
	pChild->m_pParent = this;
	m_vecChild.push_back(pChild);
}

void cUIObject::Update()
{
	UpdateWorldTM();
	UpdateChildren();
}

void cUIObject::Render( LPD3DXSPRITE pSprite )
{
	//if (m_isDebugRender)
	//{
	//	float x, y, w, h;
	//	x = m_matWorld._41;
	//	y = m_matWorld._42;
	//	w = m_stSize.fWidth;
	//	h = m_stSize.fHeight;

	//	D3DCOLOR c = D3DCOLOR_XRGB(0, 0, 0);
	//	std::vector<ST_RHWC_VERTEX> vecVertex;
	//	vecVertex.reserve(8);
	//	
	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x, y, 0, 1), c));
	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x + w, y, 0, 1), c));

	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x + w, y, 0, 1), c));
	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x + w, y + h, 0, 1), c));

	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x + w, y + h, 0, 1), c));
	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x, y + h, 0, 1), c));
	//	
	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x, y + h, 0, 1), c));
	//	vecVertex.push_back(ST_RHWC_VERTEX(D3DXVECTOR4(x, y, 0, 1), c));

	//	g_pD3DDevice->SetFVF(ST_RHWC_VERTEX::FVF);
	//	g_pD3DDevice->DrawPrimitiveUP(D3DPT_LINELIST, 4, &vecVertex[0], sizeof(ST_RHWC_VERTEX));
	//}

	for each(auto p in m_vecChild)
	{
		p->Render(pSprite);
	}
}

void cUIObject::Destroy()
{
	for each(auto p in m_vecChild)
	{
		SAFE_RELEASE(p);
	}
	Release();
}

void cUIObject::UpdateWorldTM()
{
	m_matWorld._41 = m_vPosition.x;
	m_matWorld._42 = m_vPosition.y;
	m_matWorld._43 = m_vPosition.z;

	if(m_pParent)
	{
		m_matWorld._41 += m_pParent->m_vPosition.x;
		m_matWorld._42 += m_pParent->m_vPosition.y;
		m_matWorld._43 += m_pParent->m_vPosition.z;
	}
}

void cUIObject::UpdateChildren()
{
	for each(auto p in m_vecChild)
	{
		p->Update();
	}
}

cUIObject* cUIObject::GetChildByTag( int nTag )
{
	if (m_nTag == nTag)
		return this;
	for each(auto p in m_vecChild)
	{
		cUIObject* pChild = p->GetChildByTag(nTag);

		if (pChild)
			return pChild;
	}
	return NULL;
}

