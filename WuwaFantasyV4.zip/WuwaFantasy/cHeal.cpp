#include "stdafx.h"
#include "cHeal.h"


cHeal::cHeal()
{
}


cHeal::~cHeal()
{
}

void cHeal::Update(bool& _lifeTime)
{
}
