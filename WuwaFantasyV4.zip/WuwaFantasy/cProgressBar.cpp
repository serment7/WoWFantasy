#include "stdafx.h"
#include "cProgressBar.h"

cProgressBar::cProgressBar()
{
}

cProgressBar::~cProgressBar()
{
}

void cProgressBar::Setup(int x, int y, int width, int height)
{
}

void cProgressBar::Setup(char * szUpImageFileName, char * szDownImageFileName, int x, int y, int width, int height)
{
}

void cProgressBar::Release()
{
}

void cProgressBar::Update()
{
}

void cProgressBar::Render()
{
}

void cProgressBar::SetGuage(float currentGuage, float maxGuage)
{
}
