#include "stdafx.h"
#include "cInGameScene.h"
#include "cObject.h"
#include "cHydra.h"
#include "cHydraState.h"
#include "cMonster.h"
#include "cMap.h"
#include "cUIObject.h"
#include "cUIImageView.h"
#include "cUITextView.h"
#include "cSkyBox.h"
cInGameScene::cInGameScene()
	: m_bPaused(FALSE)
	, m_fPlayTime(0.0f)
	, m_pGrid(nullptr)
	, m_pCamera(nullptr)
	, m_nSoundVolume(0)
	, m_pFont(NULL)
	, m_pSprite(NULL)
	, m_pUIRoot(NULL)
	, m_pSkyBox(NULL)
	, m_pDwarfHpProgressBar(NULL)
	, m_pHumanHpProgressBar(NULL)
	, m_pElfHpProgressBar(NULL)
	, m_pGnomeHpProgressBar(NULL)
	, m_pEnemyHpProgressBar(NULL)
	, m_pDwarfMpProgressBar(NULL)
	, m_pHumanMpProgressBar(NULL)
	, m_pElfMpProgressBar(NULL)
	, m_pGnomeMpProgressBar(NULL)
{

}

cInGameScene::~cInGameScene()
{
	g_pObjectManager->Destroy();
	SAFE_RELEASE(m_pFont);
	SAFE_RELEASE(m_pSprite);
	SAFE_RELEASE(m_pDwarfHpProgressBar);
	SAFE_RELEASE(m_pHumanHpProgressBar);
	SAFE_RELEASE(m_pElfHpProgressBar);
	SAFE_RELEASE(m_pGnomeHpProgressBar);
	SAFE_RELEASE(m_pEnemyHpProgressBar);
	SAFE_DELETE(m_pSkyBox);
	if (m_pUIRoot)
	{
		m_pUIRoot->Destroy();
		m_pUIRoot = NULL;
	}
}

void cInGameScene::Update()
{
	g_pTimeManager->Update();
	g_pMessageDispatcher->Update();
	g_pGameManager->Update();

	if (m_pUIRoot)
	{
		m_pUIRoot->Update();
	}

		m_pDwarfHpProgressBar->Update();
		m_pDwarfMpProgressBar->Update();

		m_pHumanHpProgressBar->Update();
		m_pHumanMpProgressBar->Update();

		m_pElfHpProgressBar->Update();
		m_pElfMpProgressBar->Update();
		//m_pGnomeHpProgressBar->Update();
		//m_pEnemyHpProgressBar->Update();
		/////////////////////////////////////////////



		//m_pGnomeMpProgressBar->Update();

	if (m_pPlayer) m_pPlayer->Update();

	if (m_pSkyBox) 
		m_pSkyBox->Update();

	if (m_bPaused)
		return;
	
	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Update();
	}

}

void cInGameScene::Render()
{
	g_pD3DDevice->Clear(NULL,
		NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_XRGB(47, 121, 112),
		//D3DCOLOR_XRGB(0, 0, 255),
		1.0f, 0);
	g_pD3DDevice->BeginScene();
	g_pD3DDevice->LightEnable(0, true);
	g_pD3DDevice->LightEnable(1, false);

	g_pD3DDevice->SetFVF(ST_PNT_VERTEX::FVF);

	std::vector<cMap*>& maps = g_pGameManager->GetMap();
	for (size_t i = 0; i < maps.size(); ++i)
	{
		maps[i]->Render();
	}

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Render();
	}
	if (m_pGrid) m_pGrid->Render();
	if (m_pPlayer) m_pPlayer->Render();

	//if (m_pUIRoot)
	//	m_pUIRoot->Render(m_pSprite);


	m_pDwarfHpProgressBar->Render();
	m_pHumanHpProgressBar->Render();
	m_pElfHpProgressBar->Render();
	//m_pGnomeHpProgressBar->Render();
	//m_pEnemyHpProgressBar->Render();

	////////////////////////////////////

	m_pDwarfMpProgressBar->Render();
	m_pHumanMpProgressBar->Render();
	m_pElfMpProgressBar->Render();
	//m_pGnomeMpProgressBar->Render();


	if (m_pSkyBox) m_pSkyBox->Render();
	g_pD3DDevice->EndScene();
	g_pD3DDevice->Present(NULL, NULL, NULL, NULL);
}

void cInGameScene::EnterScene()
{
	g_pKeyManager->Setup();
	m_pCamera = g_pGameManager->GetCamera();

	g_pSoundManager->AddSound("1", "1.wav");
	RECT rc;
	GetClientRect(g_hWnd, &rc);
	m_pCamera->SetAspect(rc.right / (float)rc.bottom);


	m_pSkyBox = new cSkyBox;
	m_pSkyBox->Initialize();
	
	m_pDwarfHpProgressBar = new cProgressBar;
	m_pDwarfHpProgressBar->Setup("./UI/HPbar2.png", "./UI/ProgressBar2.png", 100, 100, 300, 19);
	m_pDwarfHpProgressBar->SetGuage(100, 100);

	m_pHumanHpProgressBar = new cProgressBar;
	m_pHumanHpProgressBar->Setup("./UI/HPbar.png", "./UI/ProgressBar1.png", 100, 140, 150, 19);
	m_pHumanHpProgressBar->SetGuage(100, 100);

	m_pElfHpProgressBar = new cProgressBar;
	m_pElfHpProgressBar->Setup("./UI/HPbar - ���纻.png", "./UI/ProgressBar1 - ���纻.png", 100, 180, 150, 19);
	m_pElfHpProgressBar->SetGuage(100, 100);

	m_pGnomeHpProgressBar = new cProgressBar;
	m_pGnomeHpProgressBar->Setup("./UI/HPbar.png", "./UI/ProgressBar1.png", 100, 220, 150, 19);
	m_pGnomeHpProgressBar->SetGuage(100, 100);

	//m_pEnemyHpProgressBar = new cProgressBar;
	//m_pEnemyHpProgressBar->Setup("./UI/EnemyHPbar.png", "./UI/ProgressBar2.png", 700, 50, 300, 19);
	//m_pEnemyHpProgressBar->SetGuage(100, 100);
	/////////////////////////////////////////////////////////////////////////////
	m_pDwarfMpProgressBar = new cProgressBar;
	m_pDwarfMpProgressBar->Setup("./UI/MPbar2.png", "./UI/MpProgressBar2.png", 100, 119, 300, 9);
	m_pDwarfMpProgressBar->SetGuage(100, 100);

	m_pHumanMpProgressBar = new cProgressBar;
	m_pHumanMpProgressBar->Setup("./UI/MPbar.png", "./UI/MpProgressBar1.png", 100, 159, 150, 9);
	m_pHumanMpProgressBar->SetGuage(100, 100);

	m_pElfMpProgressBar = new cProgressBar;
	m_pElfMpProgressBar->Setup("./UI/MPbar.png", "./UI/MpProgressBar1.png", 100, 199, 150, 9);
	m_pElfMpProgressBar->SetGuage(100, 100);

	//m_pGnomeMpProgressBar = new cProgressBar;
	//m_pGnomeMpProgressBar->Setup("./UI/MPbar.png", "./UI/MpProgressBar1.png", 100, 239, 150, 9);
	//m_pGnomeMpProgressBar->SetGuage(100, 100);




	cUIImageView* pImageView = new cUIImageView;
	pImageView->SetTexture("./UI/HPbar.png");
	pImageView->SetPosition(D3DXVECTOR3(0, 0, 0));
	m_pUIRoot = pImageView;

	//cUIImageView* pImageView3 = new cUIImageView;
	//pImageView3->SetTexture("./UI/HPbar.png");
	//pImageView3->SetPosition(D3DXVECTOR3(100, 250, 0));
	//m_pUIRoot->AddChild(pImageView3);

	cUITextView* pTextView = new cUITextView;
	pTextView->SetText("�ؽ�Ʈ�Է�");
	pTextView->SetFontType(cFontManager::E_FONT_NORMAL);
	pTextView->SetPosition(D3DXVECTOR3(100, 0, 0));
	pTextView->SetSize(ST_SIZE(312, 200));
	pTextView->SetTextColor(D3DCOLOR_XRGB(255, 255, 0));
	pTextView->SetDrawTextFormat(DT_CENTER | DT_VCENTER | DT_WORDBREAK);
	pTextView->SetTag(E_TEXTVIEW);
	m_pUIRoot->AddChild(pTextView);

	cUIButton* pButton = NULL;
	pButton = new cUIButton;
	pButton->SetTexture("./UI/up.png",
		"./UI/over.png",
		"./UI/down.png");
	pButton->SetPosition(D3DXVECTOR3(-100, -50, 0));
	pButton->SetTag(E_BUTTON1);
	pButton->SetDelegate(this);
	m_pUIRoot->AddChild(pButton);

	D3DXCreateSprite(g_pD3DDevice, &m_pSprite);


	m_pPlayer = new cPlayer;
	m_pPlayer->SetTag(g_pGameManager->FindObjectType("player"));
	g_pObjectManager->AddObject(m_pPlayer);
	g_pGameManager->SetPlayerID(m_pPlayer->GetID());
	m_pPlayer->Setup();
	m_pPlayer->SetVPos(D3DXVECTOR3(256, 0, 80));

	m_pGrid = new cGrid;
	
	m_pGrid->SetTag(g_pGameManager->FindObjectType("collider"));
	g_pObjectManager->AddObject(m_pGrid);
	m_pGrid->Setup();
	
	//cGameObject* monster = new cHydra;
	cGameObject* monster = new cMonster("", D3DXVECTOR3(-15, 0, -15),new cHydraState);
	m_vecObject.push_back(monster);
	monster = new cMonster("", D3DXVECTOR3(-15, 0, 15),new cHydraState);
	m_vecObject.push_back(monster);
	monster = new cMonster("", D3DXVECTOR3(15, 0, -15), new cHydraState);
	m_vecObject.push_back(monster);
	monster = new cMonster("", D3DXVECTOR3(15, 0, 15),new cHydraState);
	m_vecObject.push_back(monster);

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Setup();
	}
	

	ZeroMemory(&m_light, sizeof(m_light));
	m_light.Type = D3DLIGHT_DIRECTIONAL;
	m_light.Direction=D3DXVECTOR3(0, 0, 1);
	D3DCOLORVALUE color;
	color.a = color.b = color.g = color.r = 255.0;
	m_light.Ambient = m_light.Diffuse = m_light.Specular = color;
	g_pD3DDevice->SetLight(0, &m_light);
	m_light.Direction = D3DXVECTOR3(0, 0, -1);
	g_pD3DDevice->SetLight(1, &m_light);

	g_pSoundManager->Start("1");

	g_pGameManager->AddMap(new cMap("HeightMap.raw","terrain.png"));
}

void cInGameScene::ExitScene()
{
	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		SAFE_RELEASE(m_vecObject[i]);
	}
	SAFE_RELEASE(m_pPlayer);
	SAFE_RELEASE(m_pGrid);
	g_pGameManager->Destroy();
	g_pObjectManager->Destroy();
	g_pTextureManager->Destroy();
	g_pKeyManager->release();
}	

void cInGameScene::ChangeScene(cIScene * _pNextScene)
{
}

void cInGameScene::MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	//static D3DXVECTOR3
	static POINT curPos;
	static bool	bRButtonDown=false;
	switch (iMessage)
	{
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MOUSEMOVE:
		if (bRButtonDown)
		{
			
		}
	case WM_MOUSEWHEEL:
		g_pGameManager->MessageHandle(hWnd, iMessage, wParam, lParam);
		break;
	case WM_RBUTTONDOWN:
		/*bRButtonDown = true;
		g_pGameManager->UpdateCursorPointInGlobal();
		curPos = g_pGameManager->GetCursorPoint();
		if (g_pPickManager->IsPickedTry(m_pGrid->GetTriVertex(), curPos.x, curPos.y))
		{
			Packet_Move* packet = new Packet_Move(g_pPickManager->GetRayPos());
			packet->vDes.y = 0.0f;
			g_pMessageDispatcher->Dispatch(0, g_pGameManager->GetPlayerID(), 0.0f, Msg_Move, packet);
		}*/
		break;
	case WM_RBUTTONUP:
		bRButtonDown = false;
	}
}

enum KeyEnum
{
	SKILL0 = '0'
	, SKILL1
	, SKILL2
	, SKILL3
	, SKILL4
	, SKILL5
	, SKILL6
	, SKILL7
	, SKILL8
	, END
};

void cInGameScene::OnClick(cUIButton* pSender)
{
	cUITextView* pTextView = (cUITextView*)m_pUIRoot->GetChildByTag(E_TEXTVIEW);
	if (pSender->GetTag() == E_BUTTON1)
	{
		char* c = "asd";
		pTextView->SetText(c);
	}
	else if (pSender->GetTag() == E_BUTTON2)
	{
		pTextView->SetText("��ư2 ����");
	}
	else if (pSender->GetTag() == E_BUTTON3)
	{
		pTextView->SetText("��ư3 ����");
	}
	else if (pSender->GetTag() == E_BUTTON4)
	{
		pTextView->SetText("��ư4 ����");
	}
	else if (pSender->GetTag() == E_BUTTON5)
	{
		pTextView->SetText("��ư5 ����");
	}
	else if (pSender->GetTag() == E_BUTTON6)
	{
		pTextView->SetText("��ư6 ����");
	}
	else if (pSender->GetTag() == E_BUTTON7)
	{
		pTextView->SetText("��ư7 ����");
	}
	else if (pSender->GetTag() == E_BUTTON8)
	{
		pTextView->SetText("��ư8 ����");
	}
	else if (pSender->GetTag() == E_BUTTON9)
	{
		pTextView->SetText("��ư9 ����");
	}
	else if (pSender->GetTag() == E_BUTTON10)
	{
		pTextView->SetText("��ư10 ����");
	}
}