#pragma once
#include "cIScene.h"
#include "cGrid.h"
#include "cPlayer.h"
#include "cCamera.h"
#include "cUIButton.h"
class cSkyBox;

enum
{
	E_BUTTON1 = 101,
	E_BUTTON2,
	E_BUTTON3,
	E_BUTTON4,
	E_BUTTON5,
	E_BUTTON6,
	E_BUTTON7,
	E_BUTTON8,
	E_BUTTON9,
	E_BUTTON10,
	E_TEXTVIEW,
};
class cUIObject;
class cGameObject;
class cProgressBar;
class cInGameScene : 
	public cIScene,
	public iUIButtonDelegate
{
private:
	bool			m_bPaused;
	float			m_fPlayTime;
	cGrid*			m_pGrid;
	cCamera*		m_pCamera;
	cPlayer*		m_pPlayer;
	cUIObject*		m_pUIRoot;
	cSkyBox*		m_pSkyBox;

	cProgressBar*	m_pDwarfHpProgressBar;
	cProgressBar*	m_pDwarfMpProgressBar;

	cProgressBar*	m_pHumanHpProgressBar;
	cProgressBar*	m_pHumanMpProgressBar;

	cProgressBar*	m_pElfHpProgressBar;
	cProgressBar*	m_pElfMpProgressBar;

	cProgressBar*	m_pGnomeHpProgressBar;
	cProgressBar*	m_pGnomeMpProgressBar;

	cProgressBar*	m_pEnemyHpProgressBar;

	int				m_nSoundVolume;

	std::vector<cGameObject*> m_vecObject;
	LPD3DXFONT		m_pFont;
	LPD3DXSPRITE	m_pSprite;
	D3DLIGHT9		m_light;

public:
	cInGameScene();
	virtual ~cInGameScene();

	virtual void	Update();
	virtual void	Render();
	virtual void	EnterScene();
	virtual void	ExitScene();
	virtual void	ChangeScene(cIScene* _pNextScene);
	virtual void	MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
	virtual void	OnClick(cUIButton* pSender) override;
};