#include "stdafx.h"
#include "cMovingObject.h"


cMovingObject::cMovingObject()
{
}


cMovingObject::~cMovingObject()
{
}
