#pragma once
#include "cGameObject.h"
class cMovingObject :
	public cGameObject
{
private:

public:
	cMovingObject();
	virtual ~cMovingObject();
};

