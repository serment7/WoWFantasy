#pragma once

#define g_pFontManager cFontManager::GetInstance()

class cFontManager
{
	SINGLETONE(cFontManager);


public:
	enum eFontType
	{
		E_FONT_NORMAL,
		E_FONT_QUEST,
	};
private:
	std::map<eFontType, LPD3DXFONT> m_mapFont;

public:
	LPD3DXFONT GetFont(eFontType e);
	void Destroy();
};

