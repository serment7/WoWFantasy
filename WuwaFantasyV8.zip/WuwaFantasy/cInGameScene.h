#pragma once
#include "cIScene.h"
#include "cGrid.h"
#include "cPlayer.h"
#include "cCamera.h"
class cUIClass;
class cSkyBox;
class cGameObject;
class cProgressBar;
class cInGameScene : 
	public cIScene
{
private:
	bool			m_bPaused;
	float			m_fPlayTime;
	cGrid*			m_pGrid;
	cCamera*		m_pCamera;
	cPlayer*		m_pPlayer;
	cSkyBox*		m_pSkyBox;
	cUIClass*		m_pUIClass;

	cProgressBar*	m_pDwarfHpProgressBar;
	cProgressBar*	m_pDwarfMpProgressBar;

	cProgressBar*	m_pHumanHpProgressBar;
	cProgressBar*	m_pHumanMpProgressBar;

	cProgressBar*	m_pElfHpProgressBar;
	cProgressBar*	m_pElfMpProgressBar;

	cProgressBar*	m_pGnomeHpProgressBar;
	cProgressBar*	m_pGnomeMpProgressBar;

	cProgressBar*	m_pEnemyHpProgressBar;

	int				m_nSoundVolume;

	std::vector<cGameObject*> m_vecObject;

	D3DLIGHT9		m_light;

public:
	cInGameScene();
	virtual ~cInGameScene();

	virtual void	Update();
	virtual void	Render();
	virtual void	EnterScene();
	virtual void	ExitScene();
	virtual void	ChangeScene(cIScene* _pNextScene);
	virtual void	MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

};