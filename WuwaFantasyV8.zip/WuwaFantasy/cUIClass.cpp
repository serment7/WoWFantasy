#include "stdafx.h"
#include "cUIClass.h"


cUIClass::cUIClass()
	: m_pFont(NULL)
	, m_pSprite(NULL)
	, m_pUIRoot(NULL)
{
}


cUIClass::~cUIClass()
{
	SAFE_RELEASE(m_pFont);
	SAFE_RELEASE(m_pSprite);
	if (m_pUIRoot)
	{
		m_pUIRoot->Destroy();
		m_pUIRoot = NULL;
	}
}
void cUIClass::EnterScene()
{
	cUIImageView* pImageView = new cUIImageView;
	pImageView->SetTexture("./UI/HUD.png");
	pImageView->SetPosition(D3DXVECTOR3(190, 464, 0));
	m_pUIRoot = pImageView;

	cUITextView* pTextView = new cUITextView;
	pTextView->SetText("�ؽ�Ʈ�Է�");
	pTextView->SetFontType(cFontManager::E_FONT_NORMAL);
	pTextView->SetPosition(D3DXVECTOR3(300, 150, 0));
	pTextView->SetSize(ST_SIZE(312, 200));
	pTextView->SetTextColor(D3DCOLOR_XRGB(255, 255, 0));
	pTextView->SetDrawTextFormat(DT_CENTER | DT_VCENTER | DT_WORDBREAK);
	pTextView->SetTag(E_TEXTVIEW);
	m_pUIRoot->AddChild(pTextView);

	cUIButton* pButton = NULL;
	pButton = new cUIButton;
	pButton->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton->SetPosition(D3DXVECTOR3(4, 4, 0));
	pButton->SetTag(E_BUTTON1);
	pButton->SetDelegate(this);
	m_pUIRoot->AddChild(pButton);

	cUIButton* pButton2 = NULL;
	pButton2 = new cUIButton;
	pButton2->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton2->SetPosition(D3DXVECTOR3(80, 4, 0));
	pButton2->SetTag(E_BUTTON2);
	pButton2->SetDelegate(this);
	m_pUIRoot->AddChild(pButton2);

	cUIButton* pButton3 = NULL;
	pButton3 = new cUIButton;
	pButton3->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton3->SetPosition(D3DXVECTOR3(156, 4, 0));
	pButton3->SetTag(E_BUTTON3);
	pButton3->SetDelegate(this);
	m_pUIRoot->AddChild(pButton3);

	cUIButton* pButton4 = NULL;
	pButton4 = new cUIButton;
	pButton4->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton4->SetPosition(D3DXVECTOR3(232, 4, 0));
	pButton4->SetTag(E_BUTTON4);
	pButton4->SetDelegate(this);
	m_pUIRoot->AddChild(pButton4);

	cUIButton* pButton5 = NULL;
	pButton5 = new cUIButton;
	pButton5->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton5->SetPosition(D3DXVECTOR3(308, 4, 0));
	pButton5->SetTag(E_BUTTON5);
	pButton5->SetDelegate(this);
	m_pUIRoot->AddChild(pButton5);

	cUIButton* pButton6 = NULL;
	pButton6 = new cUIButton;
	pButton6->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton6->SetPosition(D3DXVECTOR3(384, 4, 0));
	pButton6->SetTag(E_BUTTON6);
	pButton6->SetDelegate(this);
	m_pUIRoot->AddChild(pButton6);

	cUIButton* pButton7 = NULL;
	pButton7 = new cUIButton;
	pButton7->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton7->SetPosition(D3DXVECTOR3(460, 4, 0));
	pButton7->SetTag(E_BUTTON7);
	pButton7->SetDelegate(this);
	m_pUIRoot->AddChild(pButton7);

	cUIButton* pButton8 = NULL;
	pButton8 = new cUIButton;
	pButton8->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton8->SetPosition(D3DXVECTOR3(536, 4, 0));
	pButton8->SetTag(E_BUTTON8);
	pButton8->SetDelegate(this);
	m_pUIRoot->AddChild(pButton8);

	cUIButton* pButton9 = NULL;
	pButton9 = new cUIButton;
	pButton9->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton9->SetPosition(D3DXVECTOR3(612, 4, 0));
	pButton9->SetTag(E_BUTTON9);
	pButton9->SetDelegate(this);
	m_pUIRoot->AddChild(pButton9);

	cUIButton* pButton10 = NULL;
	pButton10 = new cUIButton;
	pButton10->SetTexture("./UI/���ָ�.png",
		"./UI/������.png",
		"./UI/����.png");
	pButton10->SetPosition(D3DXVECTOR3(688, 4, 0));
	pButton10->SetTag(E_BUTTON10);
	pButton10->SetDelegate(this);
	m_pUIRoot->AddChild(pButton10);

	cUIButton* HUNnum = NULL;
	HUNnum = new cUIButton;
	HUNnum->SetTexture("./UI/HUDNum.png",
		"./UI/HUDNum.png",
		"./UI/HUDNum.png");
	HUNnum->SetPosition(D3DXVECTOR3(0, 0, 0));
	HUNnum->SetDelegate(this);
	m_pUIRoot->AddChild(HUNnum);

	D3DXCreateSprite(g_pD3DDevice, &m_pSprite);
}

void cUIClass::Update()
{
	if (m_pUIRoot)
	{
		m_pUIRoot->Update();
	}
}

void cUIClass::Render()
{
	if (m_pUIRoot)
		m_pUIRoot->Render(m_pSprite);
}

void cUIClass::ExitScene()
{

}

void cUIClass::OnClick(cUIButton* pSender)
{
	cUITextView* pTextView = (cUITextView*)m_pUIRoot->GetChildByTag(E_TEXTVIEW);
	if (pSender->GetTag() == E_BUTTON1)
	{
		char* c = "aadasdasd";
		pTextView->SetText(c);
	}
	else if (pSender->GetTag() == E_BUTTON2)
	{
		pTextView->SetText("��ư2 ����");
	}
	else if (pSender->GetTag() == E_BUTTON3)
	{
		pTextView->SetText("��ư3 ����");
	}
	else if (pSender->GetTag() == E_BUTTON4)
	{
		pTextView->SetText("��ư4 ����");
	}
	else if (pSender->GetTag() == E_BUTTON5)
	{
		pTextView->SetText("��ư5 ����");
	}
	else if (pSender->GetTag() == E_BUTTON6)
	{
		pTextView->SetText("��ư6 ����");
	}
	else if (pSender->GetTag() == E_BUTTON7)
	{
		pTextView->SetText("��ư7 ����");
	}
	else if (pSender->GetTag() == E_BUTTON8)
	{
		pTextView->SetText("��ư8 ����");
	}
	else if (pSender->GetTag() == E_BUTTON9)
	{
		pTextView->SetText("��ư9 ����");
	}
	else if (pSender->GetTag() == E_BUTTON10)
	{
		pTextView->SetText("��ư10 ����");
	}
}