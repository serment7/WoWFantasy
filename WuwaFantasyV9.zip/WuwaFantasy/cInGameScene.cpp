#include "stdafx.h"
#include "cInGameScene.h"
#include "cObject.h"
#include "cHydra.h"
#include "cHydraState.h"
#include "cMonster.h"
#include "cMap.h"
#include "cSkyBox.h"
#include "cUIClass.h"
#include "cMiniMap.h"
cInGameScene::cInGameScene()
	: m_bPaused(FALSE)
	, m_fPlayTime(0.0f)
	, m_pGrid(nullptr)
	, m_pCamera(nullptr)
	, m_nSoundVolume(0)
	, m_pSkyBox(NULL)
	, m_pDwarfHpProgressBar(NULL)
	, m_pHumanHpProgressBar(NULL)
	, m_pElfHpProgressBar(NULL)
	, m_pGnomeHpProgressBar(NULL)
	, m_pEnemyHpProgressBar(NULL)
	, m_pDwarfMpProgressBar(NULL)
	, m_pHumanMpProgressBar(NULL)
	, m_pElfMpProgressBar(NULL)
	, m_pGnomeMpProgressBar(NULL)
	, m_pUIClass(NULL)
	, m_pMiniMap(NULL)
	, m_pSkill1(NULL)
	, m_pSkill2(NULL)
	, m_pSkill3(NULL)
	, m_pSkill4(NULL)
	, m_pSkill5(NULL)
	, m_pSkill6(NULL)
	, m_pSkill7(NULL)
	, m_pSkill8(NULL)
{

}

cInGameScene::~cInGameScene()
{

	SAFE_RELEASE(m_pDwarfHpProgressBar);
	SAFE_RELEASE(m_pDwarfMpProgressBar);

	SAFE_RELEASE(m_pHumanHpProgressBar);
	SAFE_RELEASE(m_pHumanMpProgressBar);

	SAFE_RELEASE(m_pElfHpProgressBar);
	SAFE_RELEASE(m_pElfMpProgressBar);

	SAFE_RELEASE(m_pGnomeHpProgressBar);
	SAFE_RELEASE(m_pGnomeMpProgressBar);

	SAFE_RELEASE(m_pEnemyHpProgressBar);

	SAFE_RELEASE(m_pSkill1);
	SAFE_RELEASE(m_pSkill2);
	SAFE_RELEASE(m_pSkill3);
	SAFE_RELEASE(m_pSkill4);
	SAFE_RELEASE(m_pSkill5);
	SAFE_RELEASE(m_pSkill6);
	SAFE_RELEASE(m_pSkill7);
	SAFE_RELEASE(m_pSkill8);


	SAFE_DELETE(m_pSkyBox);
	SAFE_DELETE(m_pUIClass);
	SAFE_DELETE(m_pMiniMap);

}

void cInGameScene::Update()
{
	g_pTimeManager->Update();
	g_pMessageDispatcher->Update();
	g_pGameManager->Update();


	m_pDwarfHpProgressBar->Update();
	m_pDwarfMpProgressBar->Update();
	m_pDwarfHpProgressBar->SetGuage(50, 100);
	m_pDwarfMpProgressBar->SetGuage(100, 100);

	m_pHumanHpProgressBar->Update();
	m_pHumanMpProgressBar->Update();
	m_pHumanHpProgressBar->SetGuage(100, 100);
	m_pHumanMpProgressBar->SetGuage(100, 100);

	m_pElfHpProgressBar->Update();
	m_pElfMpProgressBar->Update();
	m_pElfHpProgressBar->SetGuage(100, 100);
	m_pElfMpProgressBar->SetGuage(100, 100);

	m_pGnomeHpProgressBar->Update();
	m_pGnomeMpProgressBar->Update();
	m_pGnomeHpProgressBar->SetGuage(100, 100);
	m_pGnomeMpProgressBar->SetGuage(100, 100);

	m_pEnemyHpProgressBar->Update();
	m_pEnemyHpProgressBar->SetGuage(50, 100);

	m_pSkill1->Update();
	m_pSkill1->SetGuage(20, 100);

	m_pSkill2->Update();
	m_pSkill3->Update();
	m_pSkill4->Update();
	m_pSkill5->Update();
	m_pSkill6->Update();
	m_pSkill7->Update();
	m_pSkill8->Update();
	
	if (m_pPlayer) m_pPlayer->Update();

	m_pUIClass->Update();
	m_pMiniMap->Update();
	if (m_pSkyBox)
		m_pSkyBox->Update();

	if (m_bPaused)
		return;

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Update();
	}

}

void cInGameScene::Render()
{
	g_pD3DDevice->Clear(NULL,
		NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_XRGB(47, 121, 112),
		//D3DCOLOR_XRGB(0, 0, 255),
		1.0f, 0);
	g_pD3DDevice->BeginScene();
	g_pD3DDevice->LightEnable(0, true);
	g_pD3DDevice->LightEnable(1, false);

	g_pD3DDevice->SetFVF(ST_PNT_VERTEX::FVF);

	std::vector<cMap*>& maps = g_pGameManager->GetMap();
	for (size_t i = 0; i < maps.size(); ++i)
	{
		maps[i]->Render();
	}

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Render();
	}
	if (m_pGrid) m_pGrid->Render();
	if (m_pPlayer) m_pPlayer->Render();
	m_pUIClass->Render();
	m_pMiniMap->Render();

	m_pDwarfHpProgressBar->Render();
	m_pDwarfMpProgressBar->Render();

	m_pHumanHpProgressBar->Render();
	m_pHumanMpProgressBar->Render();

	m_pElfHpProgressBar->Render();
	m_pElfMpProgressBar->Render();

	m_pGnomeHpProgressBar->Render();
	m_pGnomeMpProgressBar->Render();

	m_pEnemyHpProgressBar->Render();

	m_pSkill1->Render();

	if (m_pSkyBox) m_pSkyBox->Render();
	g_pD3DDevice->EndScene();
	g_pD3DDevice->Present(NULL, NULL, NULL, NULL);
}

void cInGameScene::EnterScene()
{
	g_pKeyManager->Setup();
	m_pCamera = g_pGameManager->GetCamera();

	g_pSoundManager->AddSound("1", "1.wav");
	RECT rc;
	GetClientRect(g_hWnd, &rc);
	m_pCamera->SetAspect(rc.right / (float)rc.bottom);

	m_pUIClass = new cUIClass;
	m_pUIClass->EnterScene();
	m_pMiniMap = new cMiniMap;
	m_pMiniMap->EnterScene();
	m_pSkyBox = new cSkyBox;
	m_pSkyBox->Initialize();

	m_pDwarfHpProgressBar = new cProgressBar;
	m_pDwarfHpProgressBar->Setup("./Resource/UI/HPbar2.png", "./Resource/UI/ProgressBar2.png", 10, 20, 300, 19);

	m_pDwarfMpProgressBar = new cProgressBar;
	m_pDwarfMpProgressBar->Setup("./Resource/UI/MPbar2.png", "./Resource/UI/MpProgressBar2.png", 10, 39, 300, 9);

	m_pHumanHpProgressBar = new cProgressBar;
	m_pHumanHpProgressBar->Setup("./Resource/UI/HPbar.png", "./Resource/UI/ProgressBar1.png", 10, 70, 150, 19);

	m_pHumanMpProgressBar = new cProgressBar;
	m_pHumanMpProgressBar->Setup("./Resource/UI/MPbar.png", "./Resource/UI/MpProgressBar1.png", 10, 89, 150, 9);

	m_pElfHpProgressBar = new cProgressBar;
	m_pElfHpProgressBar->Setup("./Resource/UI/HPbar.png", "./Resource/UI/ProgressBar1.png", 10, 120, 150, 19);
	
	m_pElfMpProgressBar = new cProgressBar;
	m_pElfMpProgressBar->Setup("./Resource/UI/MPbar.png", "./Resource/UI/MpProgressBar1.png", 10, 139, 150, 9);

	m_pGnomeHpProgressBar = new cProgressBar;
	m_pGnomeHpProgressBar->Setup("./Resource/UI/HPbar.png", "./Resource/UI/ProgressBar1.png", 10, 170, 150, 19);

	m_pGnomeMpProgressBar = new cProgressBar;
	m_pGnomeMpProgressBar->Setup("./Resource/UI/MPbar.png", "./Resource/UI/MpProgressBar1.png", 10, 189, 150, 9);

	m_pEnemyHpProgressBar = new cProgressBar;
	m_pEnemyHpProgressBar->Setup("./Resource/UI/EnemyHPbar.png", "./Resource/UI/ProgressBar2.png", 430, 20, 300, 19);

	m_pSkill1 = new cUIProgressButton;
	m_pSkill1->Setup("./Resource/UI/���ָ�.png", "./Resource/UI/���ָ���.png", 150, 150, 72, 62);


	m_pSkill2 = new cUIProgressButton;
	m_pSkill3 = new cUIProgressButton;
	m_pSkill4 = new cUIProgressButton;
	m_pSkill5 = new cUIProgressButton;
	m_pSkill6 = new cUIProgressButton;
	m_pSkill7 = new cUIProgressButton;
	m_pSkill8 = new cUIProgressButton;


	m_pPlayer = new cPlayer;
	m_pPlayer->SetTag(g_pGameManager->FindObjectType("player"));
	g_pObjectManager->AddObject(m_pPlayer);
	g_pGameManager->SetPlayerID(m_pPlayer->GetID());
	m_pPlayer->Setup();
	m_pPlayer->SetVPos(D3DXVECTOR3(256, 0, 80));

	m_pGrid = new cGrid;

	m_pGrid->SetTag(g_pGameManager->FindObjectType("collider"));
	g_pObjectManager->AddObject(m_pGrid);
	m_pGrid->Setup();

	//cGameObject* monster = new cHydra;
	cGameObject* monster = new cMonster("", D3DXVECTOR3(-15, 0, -15), new cHydraState);
	m_vecObject.push_back(monster);
	monster = new cMonster("", D3DXVECTOR3(-15, 0, 15), new cHydraState);
	m_vecObject.push_back(monster);
	monster = new cMonster("", D3DXVECTOR3(15, 0, -15), new cHydraState);
	m_vecObject.push_back(monster);
	monster = new cMonster("", D3DXVECTOR3(15, 0, 15), new cHydraState);
	m_vecObject.push_back(monster);

	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		m_vecObject[i]->Setup();
	}


	ZeroMemory(&m_light, sizeof(m_light));
	m_light.Type = D3DLIGHT_DIRECTIONAL;
	m_light.Direction = D3DXVECTOR3(0, 0, 1);
	D3DCOLORVALUE color;
	color.a = color.b = color.g = color.r = 255.0;
	m_light.Ambient = m_light.Diffuse = m_light.Specular = color;
	g_pD3DDevice->SetLight(0, &m_light);
	m_light.Direction = D3DXVECTOR3(0, 0, -1);
	g_pD3DDevice->SetLight(1, &m_light);

	g_pSoundManager->Start("1");

	g_pGameManager->AddMap(new cMap("HeightMap.raw", "terrain.png"));
}

void cInGameScene::ExitScene()
{
	for (size_t i = 0; i < m_vecObject.size(); ++i)
	{
		SAFE_RELEASE(m_vecObject[i]);
	}
	SAFE_RELEASE(m_pPlayer);
	SAFE_RELEASE(m_pGrid);
	g_pGameManager->Destroy();
	g_pObjectManager->Destroy();
	g_pTextureManager->Destroy();
	g_pKeyManager->release();
	g_pFontManager->Destroy();
}

void cInGameScene::ChangeScene(cIScene * _pNextScene)
{
}

void cInGameScene::MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	//static D3DXVECTOR3
	static POINT curPos;
	static bool	bRButtonDown = false;
	switch (iMessage)
	{
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MOUSEMOVE:
		if (bRButtonDown)
		{

		}
	case WM_MOUSEWHEEL:
		g_pGameManager->MessageHandle(hWnd, iMessage, wParam, lParam);
		break;
	case WM_RBUTTONDOWN:
		/*bRButtonDown = true;
		g_pGameManager->UpdateCursorPointInGlobal();
		curPos = g_pGameManager->GetCursorPoint();
		if (g_pPickManager->IsPickedTry(m_pGrid->GetTriVertex(), curPos.x, curPos.y))
		{
		Packet_Move* packet = new Packet_Move(g_pPickManager->GetRayPos());
		packet->vDes.y = 0.0f;
		g_pMessageDispatcher->Dispatch(0, g_pGameManager->GetPlayerID(), 0.0f, Msg_Move, packet);
		}*/
		break;
	case WM_RBUTTONUP:
		bRButtonDown = false;
	}
}

enum KeyEnum
{
	SKILL0 = '0'
	, SKILL1
	, SKILL2
	, SKILL3
	, SKILL4
	, SKILL5
	, SKILL6
	, SKILL7
	, SKILL8
	, END
};
