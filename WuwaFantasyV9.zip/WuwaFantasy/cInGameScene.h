#pragma once
#include "cIScene.h"
#include "cGrid.h"
#include "cPlayer.h"
#include "cCamera.h"
class cUIClass;
class cMiniMap;
class cSkyBox;
class cGameObject;
class cProgressBar;
class cUIProgressButton;
class cInGameScene : 
	public cIScene
{
private:
	bool			m_bPaused;
	float			m_fPlayTime;
	cGrid*			m_pGrid;
	cCamera*		m_pCamera;
	cPlayer*		m_pPlayer;
	cSkyBox*		m_pSkyBox;
	cUIClass*		m_pUIClass;
	cMiniMap*		m_pMiniMap;
	cProgressBar*	m_pDwarfHpProgressBar;
	cProgressBar*	m_pDwarfMpProgressBar;

	cProgressBar*	m_pHumanHpProgressBar;
	cProgressBar*	m_pHumanMpProgressBar;

	cProgressBar*	m_pElfHpProgressBar;
	cProgressBar*	m_pElfMpProgressBar;

	cProgressBar*	m_pGnomeHpProgressBar;
	cProgressBar*	m_pGnomeMpProgressBar;

	cProgressBar*	m_pEnemyHpProgressBar;

	cUIProgressButton* m_pSkill1;
	cUIProgressButton* m_pSkill2;

	cUIProgressButton* m_pSkill3;
	cUIProgressButton* m_pSkill4;

	cUIProgressButton* m_pSkill5;
	cUIProgressButton* m_pSkill6;

	cUIProgressButton* m_pSkill7;
	cUIProgressButton* m_pSkill8;

	int				m_nSoundVolume;

	std::vector<cGameObject*> m_vecObject;

	D3DLIGHT9		m_light;

public:
	cInGameScene();
	virtual ~cInGameScene();

	virtual void	Update();
	virtual void	Render();
	virtual void	EnterScene();
	virtual void	ExitScene();
	virtual void	ChangeScene(cIScene* _pNextScene);
	virtual void	MessageHandling(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

};