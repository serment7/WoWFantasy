#include "stdafx.h"
#include "cMiniMap.h"

cMiniMap::cMiniMap()
	: m_pSprite(NULL)
	, m_pMiniRoot(NULL)

{
}

cMiniMap::~cMiniMap()
{
	SAFE_RELEASE(m_pSprite);
	if (m_pMiniRoot)
	{
		m_pMiniRoot->Destroy();
		m_pMiniRoot = NULL;
	}
}

void cMiniMap::EnterScene()
{
	pImageView = new cMiniMapImageView;
	pImageView->SetTexture("./Resource/MiniMap/Minimap.png");
	pImageView->SetPosition(D3DXVECTOR3(MiniMapX, MiniMapY, 0));
	m_pMiniRoot = pImageView;
	D3DXCreateSprite(g_pD3DDevice, &m_pSprite);
}

void cMiniMap::Update()
{
	if (m_pMiniRoot)
	{
		m_pMiniRoot->Update();
	}
	MiniMapX = 932;
	MiniMapY = 0;
	pImageView->SetPosition(D3DXVECTOR3(MiniMapX, MiniMapY, 0));
}
void cMiniMap::Render()
{
	if (m_pMiniRoot)
		m_pMiniRoot->Render(m_pSprite);
}
void cMiniMap::ExitScene()
{

}

