#pragma once
#include "cInGameScene.h"
#include "cMiniMapObject.h"
#include "cMiniMapImageView.h"
class cMiniMap : public cMiniMapObject
{
private:	
	LPDIRECT3DTEXTURE9 m_pTexture;
	LPD3DXSPRITE	m_pSprite;
	cMiniMapObject*		m_pMiniRoot;
	cMiniMapImageView* pImageView;
	int MiniMapX, MiniMapY;
protected:
	std::vector<cMiniMap*> m_vecChild;
	D3DXMATRIXA16			m_matWorld;
	SYNTHESIZE(ST_SIZE, m_stSize, Size);

public:
	cMiniMap();
	~cMiniMap();

	virtual void	EnterScene();
	virtual void	Update();
	virtual void	Render();
	virtual void	ExitScene();
};

