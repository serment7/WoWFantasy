#pragma once
#include "cInGameScene.h"
#include "cUIButton.h"
#include "cUIObject.h"
#include "cUIImageView.h"
#include "cUITextView.h"

enum
{
	E_BUTTON1 = 101,
	E_BUTTON2,
	E_BUTTON3,
	E_BUTTON4,
	E_BUTTON5,
	E_BUTTON6,
	E_BUTTON7,
	E_BUTTON8,
	E_BUTTON9,
	E_BUTTON10,
	E_TEXTVIEW,
};
class cUIClass : 
	public iUIButtonDelegate
{
private:
	cUIObject*		m_pUIRoot;
	LPD3DXFONT		m_pFont;
	LPD3DXSPRITE	m_pSprite;
public:
	cUIClass();
	~cUIClass();

	virtual void	Update();
	virtual void	Render();
	virtual void	EnterScene();
	virtual void	ExitScene();
	virtual void	OnClick(cUIButton* pSender) override;
};

